# coding=utf-8
# Copyright 2018 The Tensor2Tensor Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Librispeech dataset."""
import itertools
import json
import time
from functools import partial
import tensorflow as tf
import pandas as pd
import os
import random
import re
import tarfile

import concurrent.futures
import librosa

from tensor2tensor.data_generators import generator_utils, audio_encoder, text_encoder
from tensor2tensor.data_generators.speech_recognition import ByteTextEncoderWithEos, SpeechRecognitionProblem
from usr import audio
from usr.preprocessor import _process_utterance
from usr.speech_problem import SpeechProblem
from tensor2tensor.utils import registry
from tqdm import tqdm
import numpy as np

from usr.unsuper_speech_problem import UnsuperSpeechProblem

_LJSPEECH_TTS_DATASET = "http://data.keithito.com/data/speech/LJSpeech-1.1.tar.bz2"


def set_ljspeech_hparams(model_hparams):
  model_hparams.audio_sample_rate = 22050
  model_hparams.num_freq = 513  # (= n_fft / 2 + 1) only used when adding linear spectrograms post processing network
  model_hparams.rescale = True  # Whether to rescale audio prior to preprocessing
  model_hparams.rescaling_max = 0.999  # Rescaling value
  model_hparams.hop_size = 256  # For 22050Hz, 275 ~= 12.5 ms (0.0125 * sample_rate)
  model_hparams.win_size = 1024  # For 22050Hz, 1100 ~= 50 ms (If None, win_size = n_fft) (0.05 * sample_rate)
  model_hparams.preemphasize = True  # whether to apply filter
  model_hparams.preemphasis = 0.97  # filter coefficient.
  model_hparams.min_level_db = -100
  model_hparams.ref_level_db = 20
  model_hparams.fmin = 55  # Set this to 55 if your speaker is male! if female, 95 should help taking off noise. (To test depending on dataset. Pitch info: male~[65, 260], female~[100, 525])
  model_hparams.fmax = 7600  # To be increased/reduced depending on data.
  model_hparams.n_fft = 1024  # Extra window size is filled with 0 paddings to match this parameter
  model_hparams.signal_normalization = True  # Extra window size is filled with 0 paddings to match this parameter
  model_hparams.allow_clipping_in_normalization = True  # Only relevant if mel_normalization = True
  model_hparams.symmetric_mels = True  # Whether to scale the data to be symmetric around 0. (Also multiplies the output range by 2, faster and cleaner convergence)
  model_hparams.max_abs_value = 4.  # max absolute value of data. If symmetric, data will be [-max, max] else [0, max] (Must not be too big to avoid gradient explosion,

  # Griffin Lim
  model_hparams.power = 1.5  # Only used in G&L inversion, usually values between 1.2 and 1.5 are a good choice.
  model_hparams.magnitude_power = 1  # The power of the spectrogram magnitude (1. for energy, 2. for power)
  # model_hparams.magnitude_power = 2 #The power of the spectrogram magnitude (1. for energy, 2. for power)

  model_hparams.griffin_lim_iters = 60  # Number of G&L iterations, typically 30 is enough but we use 60 to ensure convergence.

  # #M-AILABS (and other datasets) trim params (there parameters are usually correct for any data, but definitely must be tuned for specific speakers)
  model_hparams.trim_fft_size = 512
  model_hparams.trim_hop_size = 128
  model_hparams.trim_top_db = 23
  model_hparams.frame_shift_ms = None  # Can replace hop_size parameter. (Recommended: 12.5)
  model_hparams.use_lws = False
  model_hparams.silence_threshold = 2  # silence threshold used for sound trimming for wavenet preprocessing
  model_hparams.trim_silence = True  # Whether to clip silence in Audio (at beginning and end of audio only, not the middle)


def do_nothing(*_):
  return None, None, None


def generator(self, use_linear, load_attn, data_dir, start_from=0, how_many=0, audio_aug=False, kd=False):
  if how_many == -1:
    how_many = 100000000
    data_split = "train"
  else:
    data_split = "test"
  raw_data_dir = os.path.join(data_dir, 'LJSpeech-1.1')

  ## download ljspeech dataset
  if not os.path.exists(raw_data_dir):
    filename = os.path.basename(_LJSPEECH_TTS_DATASET)
    compressed_file = generator_utils.maybe_download(raw_data_dir, filename, _LJSPEECH_TTS_DATASET)
    read_type = "r:bz2"
    with tarfile.open(compressed_file, read_type) as corpus_tar:
      corpus_tar.extractall(raw_data_dir)

  txt_encoder = ByteTextEncoderWithEos()
  phone_list_file = os.path.join('data/ljspeech/LJSpeech-1.1/phone_set.json')
  phone_list = json.load(open(phone_list_file))
  phone_encoder = text_encoder.TokenTextEncoder(None,
                                                vocab_list=phone_list)

  data_df = pd.read_csv(os.path.join(raw_data_dir, 'metadata_phone.csv'))
  if load_attn:
    encdec_attn_weights = np.load(os.path.join(raw_data_dir, "encdec_attn_weights.npz"))


  fn = os.path.join(raw_data_dir, f'mels_linear_{data_split}.npz' if use_linear else f'mels_{data_split}.npz')
  if os.path.exists(fn) and not audio_aug and not kd:
    data_old = np.load(fn)
    data_old_keys = data_old.keys()
  else:
    data_old_keys = set()

  with concurrent.futures.ProcessPoolExecutor(max_workers=os.cpu_count()) as executor:
    future_to_url = {
      executor.submit(self.process_wav if not kd else do_nothing,
                      raw_data_dir, r['wav'], self.model_hparams, True, audio_aug):
        (str(idx), r['phone'], r['txt2'], r['wav'])
      for idx, r
      in data_df.iloc[start_from:start_from + how_many].iterrows() if str(idx) not in data_old_keys
    }

  def produce_result(d):
    utt_id, phone, text, media_file, mel_and_linear = d
    try:
      mel_data, linear_data = mel_and_linear
    except:
      mel_data = mel_and_linear
      linear_data = None
    if audio_aug:
      mel_data, mel_data_09, mel_data_11 = mel_data

    phones = phone.split(" ")
    phones += ['|', '<EOS>']
    phones = ' '.join(phones)
    utt_id = str(utt_id)
    try:
      text_encoded = txt_encoder.encode(self.clean(text).strip())
      phone_encoded = phone_encoder.encode(phones)
    except Exception as e:
      print(e, text)
      return None

    try:
      ret = {
        "mel_data": mel_data.T.reshape(-1).tolist(),
        "inputs": text_encoded,
        "phones": phone_encoded,
        "raw_transcript": [text],
        "utt_id": [int(utt_id)],
      }
      if use_linear:
        ret['linear_data'] = linear_data.T.reshape(-1).tolist()
      if load_attn:
        if utt_id not in encdec_attn_weights:
          encdec_attn = np.zeros((len(mel_data.T), len(text_encoded)))
          mel_lens = np.ones((len(text_encoded),))
        else:
          encdec_attn = encdec_attn_weights[utt_id]
          N = 101
          att_focus = np.pad(encdec_attn.max(-1), (N // 2, N // 2), 'reflect')
          att_focus = np.convolve(att_focus, np.ones((N,)) / N, mode='valid').min()
          if att_focus < 0.8:
            return None
          mel_lens = self.attn2mel_len(encdec_attn)

        assert encdec_attn.shape[0] == mel_data.T.shape[0], (mel_data.T.shape, encdec_attn.shape)
        assert len(mel_lens) == len(text_encoded) or len(mel_lens) == len(phone_encoded)
        ret['mel_lens'] = mel_lens.tolist()
        ret['encdec_attn'] = encdec_attn.reshape(-1).tolist()
      if audio_aug:
        ret["mel_data_09"] = mel_data_09.T.reshape(-1).tolist()
        ret["mel_data_11"] = mel_data_11.T.reshape(-1).tolist()

      return ret
    except Exception as exc:
      print('generated an exception: %s, %s' % (exc, utt_id))

  uttid2mel = {}
  cached_rows = [
    (idx, r) for idx, r in data_df.iloc[start_from:start_from + how_many].iterrows()
    if str(idx) in data_old_keys
  ]

  if len(cached_rows) > 0:
    print('Loading cache rows.... Num=', len(cached_rows))
  for idx, r in tqdm(cached_rows):
    ret = produce_result((int(idx), r['phone'], r['txt2'], r['wav'], data_old[str(idx)]))
    uttid2mel[str(idx)] = data_old[str(idx)]
    if ret is not None:
      yield ret

  if kd:
    kd_teacher_outputs = np.load(os.path.join(raw_data_dir, "outputs.npz"))
  for future in tqdm(concurrent.futures.as_completed(future_to_url)):
    utt_id, phone, text, media_file = future_to_url[future]
    if not kd:
      data = future.result()
      _, mel_data, linear_data = data
    else:
      if str(utt_id) not in kd_teacher_outputs:
        yield None
        continue
      mel_data, linear_data = np.split(kd_teacher_outputs[str(utt_id)], [80], -1)
      mel_data = mel_data.T
      linear_data = linear_data.T

    ret = produce_result([int(utt_id), phone, text, media_file, (mel_data, linear_data)])
    uttid2mel[str(utt_id)] = mel_data, linear_data

    # print(mel_data[0].shape, mel_data[1].shape, mel_data[2].shape)
    # SpeechProblem.mel2wav('tmp', str(utt_id) + '_slow.wav', hparams=self.model_hparams, mel=mel_data[1])
    # SpeechProblem.mel2wav('tmp', str(utt_id) + '.wav', hparams=self.model_hparams, mel=mel_data[0])
    # SpeechProblem.mel2wav('tmp', str(utt_id) + '_quick.wav', hparams=self.model_hparams, mel=mel_data[2])
    if ret is not None:
      yield ret

  if not audio_aug and not kd:
    with open(fn, 'wb') as f:
      np.savez(f, **uttid2mel)

@registry.register_problem()
class LjspeechCharProblem(SpeechProblem):
  @property
  def num_shards(self):
    return 10

  def hparams(self, defaults=None, model_hparams=None):
    super().hparams(defaults, model_hparams)
    set_ljspeech_hparams(self.model_hparams)

  def feature_encoders(self, _):
    return {
      "inputs": ByteTextEncoderWithEos(),
      "waveforms": audio_encoder.AudioEncoder(sample_rate=22050),
      "targets": audio_encoder.AudioEncoder(sample_rate=22050),
    }

  def dataset_filename(self):
    return 'ljspeech_speech_char_problem'

  def generate_data(self, data_dir, tmp_dir, task_id=-1):
    self.hparams()
    train_paths = self.training_filepaths(
      data_dir, self.num_shards, shuffled=False)
    test_paths = self.test_filepaths(
      data_dir, self.num_test_shards, shuffled=True)
    data = generator(self, use_linear=False, load_attn=False, data_dir=data_dir, start_from=0, how_many=500)
    generator_utils.generate_files(data, test_paths)
    data = generator(self, use_linear=False, load_attn=False, data_dir=data_dir, start_from=500, how_many=-1)
    generator_utils.generate_files(data, train_paths)
    generator_utils.shuffle_dataset(train_paths)


@registry.register_problem()
class LjspeechCharLinearProblem(LjspeechCharProblem):
  def dataset_filename(self):
    return 'ljspeech_speech_char_linear_problem'

  def example_reading_spec(self):
    data_fields = {
      "inputs": tf.VarLenFeature(tf.int64),
      "mel_data": tf.VarLenFeature(tf.float32),
      "linear_data": tf.VarLenFeature(tf.float32),
      "utt_id": tf.VarLenFeature(tf.int64),
      "raw_transcript": tf.FixedLenFeature([], tf.string),
    }

    data_items_to_decoders = None
    return data_fields, data_items_to_decoders

  def generate_data(self, data_dir, tmp_dir, task_id=-1):
    self.hparams()
    train_paths = self.training_filepaths(
      data_dir, self.num_shards, shuffled=False)
    test_paths = self.test_filepaths(
      data_dir, self.num_test_shards, shuffled=True)
    data = generator(self, use_linear=True, load_attn=False, data_dir=data_dir, start_from=0, how_many=500)
    generator_utils.generate_files(data, test_paths)
    data = generator(self, use_linear=True, load_attn=False, data_dir=data_dir, start_from=500, how_many=-1)
    generator_utils.generate_files(data, train_paths)
    generator_utils.shuffle_dataset(train_paths)


@registry.register_problem()
class NALjspeechCharProblem(LjspeechCharProblem):
  def dataset_filename(self):
    return 'na_ljspeech_speech_char_problem'

  def example_reading_spec(self):
    data_fields = {
      "inputs": tf.VarLenFeature(tf.int64),
      "mel_lens": tf.VarLenFeature(tf.float32),
      "mel_data": tf.VarLenFeature(tf.float32),
      "utt_id": tf.VarLenFeature(tf.int64),
      "raw_transcript": tf.FixedLenFeature([], tf.string),
      "encdec_attn": tf.VarLenFeature(tf.float32),
    }

    data_items_to_decoders = None
    return data_fields, data_items_to_decoders

  def preprocess_example(self, example, mode, hparams):
    example = super(NALjspeechCharProblem, self).preprocess_example(example, mode, hparams)
    example["encdec_attn"] = self.process_attn(example["encdec_attn"], example["targets"], example["inputs"])
    return example

  def process_attn(self, attn, target, input):
    attn = tf.reshape(attn, [tf.shape(target)[0], -1])
    # with tf.control_dependencies([tf.assert_equal(tf.shape(attn)[0], tf.shape(target)[0]),
    #                               tf.assert_equal(tf.shape(attn)[1], tf.shape(input)[0])]):
    #   attn = tf.identity(attn)
    return attn

  def generate_data(self, data_dir, tmp_dir, task_id=-1):
    self.hparams()
    train_paths = self.training_filepaths(
      data_dir, self.num_shards, shuffled=False)
    test_paths = self.test_filepaths(
      data_dir, self.num_test_shards, shuffled=True)
    data = generator(self, use_linear=False, load_attn=True, data_dir=data_dir, start_from=1, how_many=499)
    generator_utils.generate_files(data, test_paths)
    data = generator(self, use_linear=False, load_attn=True, data_dir=data_dir, start_from=500, how_many=-1)
    generator_utils.generate_files(data, train_paths)
    generator_utils.shuffle_dataset(train_paths)

  def attn2mel_len(self, attn):
    attn_argmax = attn.argmax(-1)
    a, cnt = np.unique(attn_argmax, return_counts=True)
    b = np.zeros(attn.shape[-1])
    np.add.at(b, a, cnt)
    return b


@registry.register_problem()
class NALjspeechCharLinearProblem(NALjspeechCharProblem):
  def dataset_filename(self):
    return 'na_ljspeech_speech_char_linear_problem'

  def example_reading_spec(self):
    data_fields = {
      "inputs": tf.VarLenFeature(tf.int64),
      "mel_lens": tf.VarLenFeature(tf.float32),
      "mel_data": tf.VarLenFeature(tf.float32),
      "linear_data": tf.VarLenFeature(tf.float32),
      "utt_id": tf.VarLenFeature(tf.int64),
      "raw_transcript": tf.FixedLenFeature([], tf.string),
      "encdec_attn": tf.VarLenFeature(tf.float32),
    }

    data_items_to_decoders = None
    return data_fields, data_items_to_decoders

  def generate_data(self, data_dir, tmp_dir, task_id=-1):
    self.hparams()
    train_paths = self.training_filepaths(
      data_dir, self.num_shards, shuffled=False)
    test_paths = self.test_filepaths(
      data_dir, self.num_test_shards, shuffled=True)
    data = generator(self, use_linear=True, load_attn=True, data_dir=data_dir, start_from=1, how_many=499)
    generator_utils.generate_files(data, test_paths)
    data = generator(self, use_linear=True, load_attn=True, data_dir=data_dir, start_from=500, how_many=-1)
    generator_utils.generate_files(data, train_paths)
    generator_utils.shuffle_dataset(train_paths)


##################
# Phone problems
##################

@registry.register_problem()
class LjspeechPhoneProblem(LjspeechCharProblem):
  def hparams(self, defaults=None, model_hparams=None):
    super().hparams(defaults, model_hparams)
    self.model_hparams.symbol_size = 64

  def feature_encoders(self, _):
    phone_list_file = os.path.join('data/ljspeech/LJSpeech-1.1/phone_set.json')
    phone_list = json.load(open(phone_list_file))
    phone_encoder = text_encoder.TokenTextEncoder(None,
                                                  vocab_list=phone_list)
    return {
      "inputs": phone_encoder,
      "waveforms": audio_encoder.AudioEncoder(sample_rate=22050),
      "targets": audio_encoder.AudioEncoder(sample_rate=22050),
    }

  def example_reading_spec(self):
    data_fields = {
      "inputs": tf.VarLenFeature(tf.int64),
      "phones": tf.VarLenFeature(tf.int64),
      "mel_data": tf.VarLenFeature(tf.float32),
      "utt_id": tf.VarLenFeature(tf.int64),
      "raw_transcript": tf.FixedLenFeature([], tf.string),
    }

    data_items_to_decoders = None
    return data_fields, data_items_to_decoders

  def dataset_filename(self):
    return 'ljspeech_speech_char_problem'

  def preprocess_example(self, example, mode, hparams):
    example["text"] = example["inputs"]
    example["inputs"] = example["phones"]
    example = super(LjspeechPhoneProblem, self).preprocess_example(example, mode, hparams)
    return example


@registry.register_problem()
class LjspeechPhoneLinearProblem(LjspeechPhoneProblem):
  def example_reading_spec(self):
    data_fields = {
      "inputs": tf.VarLenFeature(tf.int64),
      "phones": tf.VarLenFeature(tf.int64),
      "mel_data": tf.VarLenFeature(tf.float32),
      "linear_data": tf.VarLenFeature(tf.float32),
      "utt_id": tf.VarLenFeature(tf.int64),
      "raw_transcript": tf.FixedLenFeature([], tf.string),
    }

    data_items_to_decoders = None
    return data_fields, data_items_to_decoders

  def dataset_filename(self):
    return 'ljspeech_speech_char_linear_problem'

  def preprocess_example(self, example, mode, hparams):
    example["text"] = example["inputs"]
    example["inputs"] = example["phones"]
    example = super(LjspeechPhoneLinearProblem, self).preprocess_example(example, mode, hparams)
    return example


@registry.register_problem()
class NALjspeechPhoneProblem(NALjspeechCharProblem):
  def hparams(self, defaults=None, model_hparams=None):
    super().hparams(defaults, model_hparams)
    self.model_hparams.symbol_size = 64

  def feature_encoders(self, _):
    phone_list_file = os.path.join('data/ljspeech/LJSpeech-1.1/phone_set.json')
    phone_list = json.load(open(phone_list_file))
    phone_encoder = text_encoder.TokenTextEncoder(None,
                                                  vocab_list=phone_list)
    return {
      "inputs": phone_encoder,
      "waveforms": audio_encoder.AudioEncoder(sample_rate=22050),
      "targets": audio_encoder.AudioEncoder(sample_rate=22050),
    }

  def example_reading_spec(self):
    data_fields = {
      "phones": tf.VarLenFeature(tf.int64),
      "mel_lens": tf.VarLenFeature(tf.float32),
      "mel_data": tf.VarLenFeature(tf.float32),
      "utt_id": tf.VarLenFeature(tf.int64),
      "raw_transcript": tf.FixedLenFeature([], tf.string),
      "encdec_attn": tf.VarLenFeature(tf.float32),
    }

    data_items_to_decoders = None
    return data_fields, data_items_to_decoders

  def dataset_filename(self):
    return 'na_ljspeech_speech_char_problem'

  def preprocess_example(self, example, mode, hparams):
    example["inputs"] = example["phones"]
    example = super(NALjspeechPhoneProblem, self).preprocess_example(example, mode, hparams)
    return example


@registry.register_problem()
class NALjspeechPhoneLinearProblem(NALjspeechCharLinearProblem):
  def hparams(self, defaults=None, model_hparams=None):
    super().hparams(defaults, model_hparams)
    self.model_hparams.symbol_size = 64

  def feature_encoders(self, _):
    phone_list_file = os.path.join('data/ljspeech/LJSpeech-1.1/phone_set.json')
    phone_list = json.load(open(phone_list_file))
    phone_encoder = text_encoder.TokenTextEncoder(None,
                                                  vocab_list=phone_list)
    return {
      "inputs": phone_encoder,
      "waveforms": audio_encoder.AudioEncoder(sample_rate=22050),
      "targets": audio_encoder.AudioEncoder(sample_rate=22050),
    }

  def example_reading_spec(self):
    data_fields = {
      "phones": tf.VarLenFeature(tf.int64),
      "mel_lens": tf.VarLenFeature(tf.float32),
      "mel_data": tf.VarLenFeature(tf.float32),
      "linear_data": tf.VarLenFeature(tf.float32),
      "utt_id": tf.VarLenFeature(tf.int64),
      "raw_transcript": tf.FixedLenFeature([], tf.string),
      "encdec_attn": tf.VarLenFeature(tf.float32),
    }

    data_items_to_decoders = None
    return data_fields, data_items_to_decoders

  def dataset_filename(self):
    return 'na_ljspeech_speech_char_linear_problem'

  def preprocess_example(self, example, mode, hparams):
    example["inputs"] = example["phones"]
    example = super(NALjspeechCharLinearProblem, self).preprocess_example(example, mode, hparams)
    return example


@registry.register_problem()
class NALjspeechPhoneKdProblem(NALjspeechPhoneProblem):
  def dataset_filename(self):
    return 'na_ljspeech_speech_char_kd_problem'

  def generate_data(self, data_dir, tmp_dir, task_id=-1):
    self.hparams()
    train_paths = self.training_filepaths(
      data_dir, self.num_shards, shuffled=False)
    test_paths = self.test_filepaths(
      data_dir, self.num_test_shards, shuffled=True)
    data = generator(self, use_linear=False, load_attn=True, data_dir=data_dir, start_from=1, how_many=499)
    generator_utils.generate_files(data, test_paths)
    data = generator(self, use_linear=False, load_attn=True, data_dir=data_dir, start_from=500, how_many=-1, kd=True)
    generator_utils.generate_files(data, train_paths)
    generator_utils.shuffle_dataset(train_paths)


@registry.register_problem()
class NALjspeechPhoneKdLinearProblem(NALjspeechPhoneLinearProblem):
  def dataset_filename(self):
    return 'na_ljspeech_speech_char_kd_linear_problem'

  def generate_data(self, data_dir, tmp_dir, task_id=-1):
    self.hparams()
    train_paths = self.training_filepaths(
      data_dir, self.num_shards, shuffled=False)
    test_paths = self.test_filepaths(
      data_dir, self.num_test_shards, shuffled=True)
    data = generator(self, use_linear=True, load_attn=True, data_dir=data_dir, start_from=1, how_many=499)
    generator_utils.generate_files(data, test_paths)
    data = generator(self, use_linear=True, load_attn=True, data_dir=data_dir, start_from=500, how_many=-1, kd=True)
    generator_utils.generate_files(data, train_paths)
    generator_utils.shuffle_dataset(train_paths)


#########################
# Unsupervised problems
#########################

@registry.register_problem()
class LjspeechUnsuperPhoneProblem(UnsuperSpeechProblem):

  @property
  def num_shards(self):
    return 100

  def hparams(self, defaults=None, model_hparams=None):
    super().hparams(defaults, model_hparams)
    set_ljspeech_hparams(self.model_hparams)
    self.model_hparams.symbol_size = 64

  def feature_encoders(self, _):
    phone_list_file = os.path.join('data/ljspeech/LJSpeech-1.1/phone_set.json')
    phone_list = json.load(open(phone_list_file))
    phone_encoder = text_encoder.TokenTextEncoder(None,
                                                  vocab_list=phone_list)
    return {
      "inputs": phone_encoder,
      "waveforms": audio_encoder.AudioEncoder(sample_rate=22050),
      "targets": audio_encoder.AudioEncoder(sample_rate=22050),
    }

  def generate_data(self, data_dir, tmp_dir, task_id=-1):
    self.hparams()
    train_paths = self.training_filepaths(
      data_dir, self.num_shards, shuffled=False)
    test_paths = self.test_filepaths(
      data_dir, self.num_test_shards, shuffled=True)
    data = generator(self, use_linear=False, load_attn=False, data_dir=data_dir, start_from=0, how_many=500,
                     audio_aug=True)
    generator_utils.generate_files(data, test_paths)
    data = generator(self, use_linear=False, load_attn=False, data_dir=data_dir, start_from=500, how_many=-1,
                     audio_aug=True)
    generator_utils.generate_files(data, train_paths)
    generator_utils.shuffle_dataset(train_paths)

  def example_reading_spec(self):
    data_fields = {
      "phones": tf.VarLenFeature(tf.int64),
      "mel_data": tf.VarLenFeature(tf.float32),
      "utt_id": tf.VarLenFeature(tf.int64),
      "raw_transcript": tf.FixedLenFeature([], tf.string),
    }
    if 0 < self.model_hparams.para_data < 200:
      data_fields["mel_data_09"] = tf.VarLenFeature(tf.float32)
      data_fields["mel_data_11"] = tf.VarLenFeature(tf.float32)

    data_items_to_decoders = None
    return data_fields, data_items_to_decoders

  def dataset_filename(self):
    return 'ljspeech_unsuper_phone_problem'

  def preprocess_example(self, example, mode, hparams):
    example["inputs"] = example.pop("phones")
    example = super(LjspeechUnsuperPhoneProblem, self).preprocess_example(example, mode, hparams)
    if 0 < self.model_hparams.para_data < 200:
      example["targets_09"] = self.process_mel(hparams, example.pop('mel_data_09'))
      example["targets_11"] = self.process_mel(hparams, example.pop('mel_data_11'))
    return example


@registry.register_problem()
class LjspeechUnsuperPhoneLinearProblem(LjspeechUnsuperPhoneProblem):
  def example_reading_spec(self):
    data_fields = {
      "phones": tf.VarLenFeature(tf.int64),
      "mel_data": tf.VarLenFeature(tf.float32),
      "utt_id": tf.VarLenFeature(tf.int64),
      "linear_data": tf.VarLenFeature(tf.float32),
      "raw_transcript": tf.FixedLenFeature([], tf.string),
    }
    data_items_to_decoders = None
    return data_fields, data_items_to_decoders

  def dataset_filename(self):
    return 'ljspeech_speech_char_linear_problem'
