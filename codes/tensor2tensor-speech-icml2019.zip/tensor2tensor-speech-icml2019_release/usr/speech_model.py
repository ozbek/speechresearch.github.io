from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import six
from six.moves import range  # pylint: disable=redefined-builtin
from tensor2tensor.layers.transformer_layers import transformer_encoder, transformer_prepare_encoder, \
  transformer_ffn_layer
from usr import audio

from usr.audio_modules import SpeechRecognitionModality, TTSModality, \
  SpeechSymbolModality

from tensor2tensor.layers import common_attention
from tensor2tensor.layers import common_layers
from tensor2tensor.models.transformer import Transformer, transformer_base_v3, transformer_base, features_to_nonpadding, \
  transformer_decoder, transformer_prepare_decoder
from tensor2tensor.utils import beam_search, expert_utils
from tensor2tensor.utils import mlperf_log
from tensor2tensor.utils import registry

import tensorflow as tf
from tensorflow.python.util import nest

# Alias some commonly reused layers, here and elsewhere.
from tensor2tensor.utils.t2t_model import _log_variable_sizes, log_info, remove_summaries, _del_dict_non_tensors, \
  average_sharded_losses
from usr.session_hook import RecordStepHook
import matplotlib.pyplot as plt
import numpy as np
import os

flags = tf.flags
FLAGS = flags.FLAGS


def plot_att(att):
  fig, ax = plt.subplots(figsize=(12, 8))
  att = att.T
  im = ax.imshow(att, aspect='auto', origin='lower',
                 interpolation='none')
  try:
    fig.colorbar(im, ax=ax)
    fig.canvas.draw()
    data = np.fromstring(fig.canvas.tostring_rgb(), dtype=np.uint8, sep='')
    data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
    plt.cla()
    plt.close(fig)
  except Exception as e:
    print(e)
    print(">> ", att.shape)
    data = np.zeros([10, 10, 3], dtype=np.uint8)
  return data[None, :]


@registry.register_model
class SpeechModel(Transformer):
  def __init__(self, *args, **kwargs):
    super().__init__(*args, **kwargs)
    self._is_training_at_beginning = self.hparams.mode == tf.estimator.ModeKeys.TRAIN
    self.gpus = self._data_parallelism.n
    self.gpu_id = 0
    self.attention_weights = {}
    self.hparams.shared_embedding_and_softmax_weights = True
    self.gta = True if self._decode_hparams.get("gta") else False
    self.predict_mode = False
    self.master = False
    hparams = self._hparams

    if not self.hparams.share_text_mod:
      self.text_modalities = SpeechSymbolModality(
        self.hparams, self.hparams.get('symbol_size', 256), 'txt_modality')
      self.text_enc_modalities = SpeechSymbolModality(
        self.hparams, self.hparams.get('symbol_size', 256), 'enc_txt_modality')
      self.text_dec_modalities = SpeechSymbolModality(
        self.hparams, self.hparams.get('symbol_size', 256), 'dec_txt_modality')
    else:
      self.text_modalities = self.text_dec_modalities = self.text_enc_modalities = \
        SpeechSymbolModality(self.hparams, self.hparams.get('symbol_size', 256))

    if getattr(hparams, 'enc_modality', False) and hparams.enc_modality == 'dense':
      self.speech_enc_modalities = TTSModality(self.hparams)
    else:
      self.speech_enc_modalities = SpeechRecognitionModality(self.hparams)
    self.speech_dec_modalities = TTSModality(self.hparams)

    self.encoder_layer_prefix = ''
    self.decoder_layer_prefix = ''

    self.set_modules_and_get_features(hparams.run_type)

    self.txt_encoder = self._problem_hparams.vocabulary["inputs"]

  def body(self, features, encoder_output=None):
    hparams = self._hparams
    losses = []
    inputs = features["inputs"]
    target_space = features["target_space_id"]
    inputs_flatten = common_layers.flatten4d3d(features["inputs"])
    inputs_nonpadding = 1.0 - common_attention.embedding_to_padding(inputs_flatten)  # shape: (bs, input_len)

    if encoder_output is None:
      encoder_output, encoder_decoder_attention_bias = self.encode(
        inputs, target_space, hparams, features=features, losses=losses, no_padding=inputs_nonpadding)
    else:
      encoder_output, encoder_decoder_attention_bias = encoder_output

    targets = features["targets"]
    targets_shape = common_layers.shape_list(targets)
    targets = common_layers.flatten4d3d(targets)

    decoder_input, decoder_self_attention_bias = transformer_prepare_decoder(
      targets, hparams, features=features)

    # add start token flag embed (for unsupervised model)
    stoken = features.get('stoken', None)
    if stoken is not None:
      hs = decoder_input.get_shape().as_list()[-1]
      reverse_embedding = common_layers.embedding(
        stoken, 4, hs, name="target_flag_embedding")
      reverse_embedding = tf.reshape(reverse_embedding, [-1, 1, hs])
      decoder_input += reverse_embedding
      # decoder_input = tf.concat([reverse_embedding, decoder_input[:, 1:]], 1)

    decoder_output = self.decode(
      decoder_input,
      encoder_output,
      encoder_decoder_attention_bias,
      decoder_self_attention_bias,
      hparams,
      nonpadding=features_to_nonpadding(features, "targets"),
      losses=losses,
    )

    # plot attention
    plt_data_of_layers = []
    with tf.name_scope("attn"):
      if hparams.plot_attention and self.master:
        def combine_attentions(attention_list):
          attentions = tf.stack(attention_list)  # shape: [layer, bs, heads, length_q, length_kv]
          return tf.reduce_mean(attentions, [0, 2])  # reduce mean along layer and heads (not bs)

        actual_encdec_attention_weights = [
          t for layer_key, t in self.attention_weights.items()  # shape: [bs, heads, length_q, length_kv]
          if "encdec_attention" in layer_key and "/logits" not in layer_key
        ]
        actual_attention_weights = combine_attentions(actual_encdec_attention_weights)

        # plot attn of each layer
        attn_weights_each_layer = {
          layer_key: t for layer_key, t in self.attention_weights.items()
          # shape: [bs, heads, length_q, length_kv]
          if "encdec_attention" in layer_key and "/logits" not in layer_key
        }
        for layer_key, layer_attn_weight in sorted(attn_weights_each_layer.items(), key=lambda d: d[0]):
          # combine attn for each layer
          layer_attn_weight = combine_attentions([layer_attn_weight])  # shape: [bs, length_q, length_kv]
          layer_name = layer_key[layer_key.find('layer'):layer_key.find('/', layer_key.find('layer'))]
          plt_data = tf.py_func(plot_att, [layer_attn_weight[0]], tf.uint8)
          plt_data_of_layers.append(plt_data)
          tf.summary.image("encdec_attention_" + layer_name, plt_data)
        # plot average attention weights
        plt_data = tf.py_func(plot_att, [actual_attention_weights[0]], tf.uint8)
        tf.summary.image("encdec_attention_avg", plt_data)
        # plot saved attention weights
        if features.get("encdec_attn") is not None:
          plt_data2 = tf.py_func(plot_att, [features["encdec_attn"][0]], tf.uint8)
          plt_data_of_layers.append(plt_data2)
          tf.summary.image("saved_encdec_attention", plt_data2)
      else:
        plt_data = tf.constant(0.0)

    with tf.control_dependencies([plt_data] + plt_data_of_layers):
      decoder_output = tf.reshape(decoder_output, targets_shape)

    ret = {
      "decoder_output": decoder_output,
      "encoder_output": encoder_output,
      "encoder_decoder_attention_bias": encoder_decoder_attention_bias
    }

    if losses:
      return ret, {"extra_loss": tf.add_n(losses)}
    else:
      return ret

  def _model_fn_with_eout(self, features, encoder_output=None):
    with tf.variable_scope(tf.get_variable_scope(), use_resource=True) as vs:
      self._add_variable_scope("model_fn", vs)
      transformed_features = self.bottom(features)

      with tf.variable_scope("body", reuse=tf.AUTO_REUSE) as body_vs:
        self._add_variable_scope("body", body_vs)
        log_info("Building model body")
        body_out = self.body(transformed_features, encoder_output)
      body_out, losses = self._normalize_body_output(body_out)
      body_out['logits'] = self.top(body_out['decoder_output'], features)
      training_loss = self.loss(body_out['logits'], features)
      if isinstance(training_loss[0], list):
        training_loss = training_loss[0]
        losses['training'] = training_loss[0], tf.constant(1.0)
        losses['postnet_loss'] = tf.cond(
          tf.greater(tf.train.get_global_step(), self.hparams.postnet_start_at),
          true_fn=lambda: training_loss[1], false_fn=lambda: tf.constant(0.0))
        losses['linear_loss'] = tf.cond(
          tf.greater(tf.train.get_global_step(), self.hparams.postnet_start_at),
          true_fn=lambda: training_loss[2], false_fn=lambda: tf.constant(0.0))
        losses['stop_loss'] = training_loss[3]
      else:
        losses['training'] = training_loss
      return body_out, losses

  def print_loss_in_model_fn(self, losses, features, run_type):
    txt = f"[{run_type}]"
    print_tensor = []
    for k, v in losses.items():
      if isinstance(v, list) or isinstance(v, tuple):
        print_tensor.append(v[0] / v[1])
      else:
        print_tensor.append(v)
      txt += k + ", "
    print_tensor.append(tf.shape(features["inputs"]))
    txt += 'inputs_shape: '
    return print_tensor, txt

  def model_fn(self, features, run_type=None, encoder_output=None, random_print=False):
    """

    :param features:
    :param run_type:
    :param print_vars:
    :param return_encoder_out:
    :param encoder_output:
    :return:
    """
    if run_type is None:
      run_type = self.hparams.run_type
    features = self.set_modules_and_get_features(run_type, features)
    model_fn_out, losses = self._model_fn_with_eout(features, encoder_output)

    maybe_print = []
    if self.is_training:
      print_tensor, txt = self.print_loss_in_model_fn(losses, features, run_type)
      if not random_print:
        maybe_print = [tf.cond(
          tf.equal(tf.mod(tf.train.get_global_step(), 50), 0),
          true_fn=lambda: tf.print(
            tf.constant(0.0),
            print_tensor,
            message=txt, summarize=100),
          false_fn=lambda: tf.constant(0.0)
        )]
      else:
        maybe_print = [tf.cond(
          tf.less(tf.random_uniform([], 0., 1.), tf.constant(0.05)),
          true_fn=lambda: tf.print(
            tf.constant(0.0),
            print_tensor,
            message=txt, summarize=100),
          false_fn=lambda: tf.constant(0.0)
        )]
    else:
      losses['training'] = tf.constant(0.0), tf.constant(1.0)
    with tf.control_dependencies(maybe_print):
      if isinstance(losses['training'], tuple):
        losses['training'] = tf.identity(losses['training'][0]), losses['training'][1]
      else:
        losses['training'] = tf.identity(losses['training'])
    return model_fn_out, losses

  def model_fn_with_gpu_id(self, gpu_id):
    def wrapped_model_fn(features, run_type=None, encoder_output=None):
      self.gpu_id = gpu_id
      if gpu_id == 0:
        self.master = True
      else:
        self.master = False
      return self.model_fn(features, run_type, encoder_output)

    return wrapped_model_fn

  def call(self, inputs, **kwargs):
    ret = super(SpeechModel, self).call(inputs, **kwargs)
    _log_variable_sizes(tf.trainable_variables(), "Trainable Variables")
    return ret

  def model_fn_sharded(self, sharded_features):
    dp = self._data_parallelism
    n_devices = dp.n
    fns = [self.model_fn_with_gpu_id(i) for i in range(n_devices)]
    datashard_to_features = self._to_features_per_datashard(sharded_features)
    sharded_logits, sharded_losses = dp(fns, datashard_to_features)
    if isinstance(sharded_logits[0], dict):
      temp_dict = {k: [] for k, _ in six.iteritems(sharded_logits[0])}
      for k, _ in six.iteritems(sharded_logits[0]):
        for l in sharded_logits:
          temp_dict[k].append(l[k])
      sharded_logits = temp_dict
    losses = average_sharded_losses(sharded_losses)
    return sharded_logits, losses

  def encode(self, inputs, target_space, hparams, features=None, losses=None,
             layer_names=None, encoder_input=None, self_attention_bias=None, conv_padding='SAME', no_padding=None):
    if encoder_input is None:
      inputs = common_layers.flatten4d3d(inputs)
      encoder_input, self_attention_bias, encoder_decoder_attention_bias = (
      transformer_prepare_encoder(
        inputs, target_space, hparams, features=features))
      mlperf_log.transformer_print(
        key=mlperf_log.MODEL_HP_LAYER_POSTPROCESS_DROPOUT,
        value=hparams.layer_prepostprocess_dropout)

      encoder_input = tf.nn.dropout(encoder_input,
                                    1.0 - hparams.layer_prepostprocess_dropout)
    else:
      encoder_decoder_attention_bias = None

    if layer_names is None:
      layer_names = self.get_encoder_layer_names()

    encoder_output = transformer_encoder(
      encoder_input,
      self_attention_bias,
      hparams,
      nonpadding=features_to_nonpadding(features, "inputs") if no_padding is None else no_padding,
      save_weights_to=self.attention_weights,
      make_image_summary=not common_layers.is_xla_compiled(),
      losses=losses,
      name=layer_names,
      conv_padding=conv_padding)

    return encoder_output, encoder_decoder_attention_bias

  def decode(self,
             decoder_input,
             encoder_output,
             encoder_decoder_attention_bias,
             decoder_self_attention_bias,
             hparams,
             cache=None,
             decode_loop_step=None,
             nonpadding=None,
             losses=None,
             return_attn=False,
             layer_names=None):
    mlperf_log.transformer_print(
      key=mlperf_log.MODEL_HP_LAYER_POSTPROCESS_DROPOUT,
      value=hparams.layer_prepostprocess_dropout)
    decoder_input = tf.nn.dropout(decoder_input,
                                  1.0 - hparams.layer_prepostprocess_dropout)
    if layer_names is None:
      layer_names = self.get_decoder_layer_names()
    decoder_outputs = transformer_decoder(
      decoder_input,
      encoder_output,
      decoder_self_attention_bias,
      encoder_decoder_attention_bias,
      hparams,
      cache=cache,
      decode_loop_step=decode_loop_step,
      nonpadding=nonpadding,
      save_weights_to=self.attention_weights,
      name=layer_names,
      losses=losses,
      return_attn=return_attn)
    if isinstance(decoder_outputs, tuple):
      decoder_output, attention_weight, attention_logits = decoder_outputs
      return tf.expand_dims(decoder_output, axis=2), attention_weight, attention_logits
    else:
      decoder_output = decoder_outputs
      return tf.expand_dims(decoder_output, axis=2)

  def loss(self, logits, features):
    return self._problem_hparams.modality["targets"].loss(logits, features["targets"])

  id2attn = None
  id2outputs = None

  def _fast_decode(self,
                   features,
                   decode_length,
                   beam_size=1,
                   top_beams=1,
                   alpha=1.0,
                   run_type=None):
    run_type = run_type or self._hparams.run_type
    dp = self._data_parallelism
    sharded_features = self._shard_features(features)
    datashard_to_features = self._to_features_per_datashard(sharded_features)
    sharded_logits = dp(self._fast_decode_one_shard,
                        datashard_to_features,
                        decode_length,
                        beam_size=beam_size,
                        top_beams=top_beams,
                        alpha=alpha,
                        run_type=run_type)
    _log_variable_sizes(tf.trainable_variables(), f"[inference]{run_type} Trainable Variables")
    if isinstance(sharded_logits[0], dict):
      temp_dict = {k: [] for k, _ in six.iteritems(sharded_logits[0])}
      for k, _ in six.iteritems(sharded_logits[0]):
        shapes = []
        for l in sharded_logits:
          if l[k] is not None:
            shapes.append(l[k].get_shape().as_list())
        shapes_max_len = [0] * len(shapes[0])
        for dim, _ in enumerate(shapes[0]):
          for l_idx, l in enumerate(sharded_logits):
            shapes_max_len[dim] = tf.maximum(shapes_max_len[dim], tf.shape(l[k])[dim])
        padding_value = 0.
        if k == 'hit_eos':
          padding_value = True
        for l_idx, l in enumerate(sharded_logits):
          l[k] = tf.pad(l[k],
                        [[0, max_len - tf.shape(l[k])[dim]]
                         for dim, max_len in enumerate(shapes_max_len)],
                        constant_values=common_layers.cast_like(padding_value, l[k]))

        for l in sharded_logits:
          temp_dict[k].append(l[k])
        temp_dict[k] = tf.concat(temp_dict[k], 0)
      sharded_logits = temp_dict

    if self._decode_hparams.get("save_attention_weights") is True:
      SpeechModel.id2attn = {}
      SpeechModel.id2outputs = {}

      outputs = sharded_logits['outputs']
      utt_ids = sharded_logits['utt_ids']
      inputs_length = sharded_logits['inputs_length']
      targets_length = sharded_logits['targets_length']
      encdec_attn = sharded_logits['encdec_attn']
      if 'mels' in sharded_logits:
        outputs = tf.concat([sharded_logits['mels'], outputs], -1)

      def dump(encdec_attn, inputs_len, targets_len, utt_ids, outputs):
        bs = utt_ids.shape[0]
        inputs_len = inputs_len.astype(np.int16)
        targets_len = targets_len.astype(np.int16)
        for i in range(bs):
          if inputs_len[i] > 0 and targets_len[i] > 0:
            utt_id = utt_ids[i]
            attn = encdec_attn[i, :, :targets_len[i], :inputs_len[i]]
            attn = attn[attn.max(-1).sum(-1).argmax(-1)]
            SpeechModel.id2attn[str(utt_id)] = attn
            SpeechModel.id2outputs[str(utt_id)] = outputs[i, :targets_len[i]]
        return np.array(0.0, np.float32)

      with tf.control_dependencies([tf.py_func(dump, [
        tf.nn.softmax(encdec_attn, -1), inputs_length, targets_length, utt_ids, outputs], tf.float32)]):
        sharded_logits["outputs"] = tf.identity(sharded_logits["outputs"])

    return sharded_logits

  def choose_mono_attn(self, encdec_attn_logits):
    # encdec_attn_logits: [bs, layer, head, target_len, input_len]
    encdec_logits_shape = common_layers.shape_list(encdec_attn_logits)
    encdec_logits = tf.reshape(encdec_attn_logits,
                               [encdec_logits_shape[0], encdec_logits_shape[1] * encdec_logits_shape[2],
                                *encdec_logits_shape[3:]])
    encdec_attn_all = tf.nn.softmax(encdec_logits, -1)
    attn_idx = tf.argmax(tf.reduce_sum(tf.reduce_max(encdec_attn_all, -1), -1), -1)  # [bs]
    attn_idx = tf.cast(attn_idx, tf.int32)
    attn_idx = tf.stack([tf.range(0, tf.shape(attn_idx)[0]), attn_idx], 1)  # [bs, 2]
    encdec_attn = tf.gather_nd(encdec_attn_all, attn_idx)  # [bs, target_len, input_len]
    return encdec_attn, encdec_attn_all

  def _fast_decode_one_shard(self,
                             features,
                             decode_length,
                             beam_size=1,
                             top_beams=1,
                             alpha=1.0,
                             run_type=None):
    tgt = run_type.split("->")[-1][0]
    self.encoder_layer_prefix, self.decoder_layer_prefix = run_type.split("->")

    features = self.set_modules_and_get_features(run_type, features)

    hparams = self._hparams
    target_modality = self._problem_hparams.modality["targets"]
    inputs = features["inputs"]
    if target_modality.is_class_modality:
      decode_length = 1
    elif self.gta:
      decode_length = common_layers.shape_list(features['targets'])[1]
    else:
      if tgt == 't':
        decode_length = (
            common_layers.shape_list(inputs)[1] // 4 + features.get(
          "decode_length", decode_length))
      else:
        decode_length = tf.minimum(common_layers.shape_list(inputs)[1] * 4 + 400, 1000)

    s = common_layers.shape_list(inputs)
    inputs = tf.reshape(inputs, [s[0], 1, s[1], 1 if len(s) < 3 else s[2], 1])
    s = common_layers.shape_list(inputs)
    batch_size = s[0]
    inputs = tf.reshape(inputs, [s[0] * s[1], s[2], s[3], s[4]])
    input_modality = self._problem_hparams.modality["inputs"]
    with tf.variable_scope(input_modality.name, reuse=tf.AUTO_REUSE):
      inputs = input_modality.bottom(inputs)

    # inputs_flatten = common_layers.flatten4d3d(features["inputs"])
    # inputs_nonpadding = 1.0 - common_attention.embedding_to_padding(inputs_flatten)  # shape: (bs, input_len)
    with tf.variable_scope("body", reuse=tf.AUTO_REUSE):
      encoder_output, encoder_decoder_attention_bias = self.encode(
        inputs,
        features["target_space_id"],
        hparams,
        features=features,
        # no_padding=inputs_nonpadding
      )
    if hparams.pos == "timing":
      positional_encoding = common_attention.get_timing_signal_1d(
        decode_length + 1, hparams.hidden_size, use_scale=hparams.pos_scale,
        var_name='body/targets_positional_embedding')
    elif hparams.pos == "emb":
      positional_encoding = common_attention.add_positional_embedding(
        tf.zeros([1, decode_length, hparams.hidden_size]),
        hparams.max_length, "body/{}targets_positional_embedding".format(tgt), None)
    else:
      positional_encoding = None

    def preprocess_targets(targets, i):
      with tf.variable_scope(target_modality.name):
        targets = target_modality.targets_bottom(targets)
      targets = common_layers.flatten4d3d(targets)

      pad_value = tf.zeros_like(targets)
      targets = tf.cond(
        tf.equal(i, 0), lambda: pad_value, lambda: targets)

      # for unsupervised TTS&ASR start token
      stoken = features.get('stoken', None)
      if stoken is not None:
        with tf.variable_scope("body", reuse=tf.AUTO_REUSE):
          hs = self.hparams.hidden_size
          reverse_embedding = common_layers.embedding(
            stoken, 4, hs, name="target_flag_embedding")
        targets += tf.reshape(reverse_embedding, [-1, 1, hs])

      if positional_encoding is not None:
        targets += positional_encoding[:, i:i + 1]
      return targets

    decoder_self_attention_bias = (
      common_attention.attention_bias_lower_triangle(decode_length))
    if hparams.proximity_bias:
      decoder_self_attention_bias += common_attention.attention_bias_proximal(
        decode_length)

    if encoder_output is not None:
      batch_size = common_layers.shape_list(encoder_output)[0]

    key_channels = hparams.attention_key_channels or hparams.hidden_size
    value_channels = hparams.attention_value_channels or hparams.hidden_size
    num_layers = hparams.num_decoder_layers or hparams.num_hidden_layers
    vars_3d_num_heads = (
      hparams.num_heads if hparams.get("attention_variables_3d") else 0)

    cache = {
      "layer_%d" % layer: {
        "k":  # [batch, num_heads, length, channels / num_heads]
          common_attention.split_heads(
            tf.zeros([batch_size, 0, key_channels]), hparams.num_heads),
        "v":  # [batch, num_heads, length, channels / num_heads]
          common_attention.split_heads(
            tf.zeros([batch_size, 0, value_channels]), hparams.num_heads),
        "f":
          tf.zeros([batch_size, 0, hparams.hidden_size]),
      } for layer in range(num_layers)
    }

    if tgt == 's' and hparams.attn_constraint:
      for layer in range(num_layers):
        cache["layer_%d" % layer]['enc_dec_attn_constraint_masks'] = tf.zeros(
          [batch_size, hparams.num_heads, 1, tf.shape(encoder_output)[1]])

    decoder_prefix = self.get_decoder_layer_names()
    for layer in range(num_layers):
      layer_name = "layer_%d" % layer
      with tf.variable_scope(
          "body/%s/%s/encdec_attention/multihead_attention" % (
              decoder_prefix if isinstance(decoder_prefix, str) else decoder_prefix[layer], layer_name)):
        k_encdec = common_attention.compute_attention_component(
          encoder_output, key_channels, name="k",
          vars_3d_num_heads=vars_3d_num_heads)
        k_encdec = common_attention.split_heads(k_encdec, hparams.num_heads)
        v_encdec = common_attention.compute_attention_component(
          encoder_output, value_channels, name="v",
          vars_3d_num_heads=vars_3d_num_heads)
        v_encdec = common_attention.split_heads(v_encdec, hparams.num_heads)
      cache[layer_name]["k_encdec"] = k_encdec
      cache[layer_name]["v_encdec"] = v_encdec

    cache["encoder_decoder_attention_bias"] = encoder_decoder_attention_bias
    cache["encoder_output"] = encoder_output

    def symbols_to_logits_fn(ids, i, cache):
      targets = tf.expand_dims(ids, axis=3)

      if self.gta:
        targets = tf.cond(
          tf.equal(i, 0),
          lambda: tf.zeros_like(features['targets'][:, 0:1, :, :], dtype=features['targets'].dtype),
          lambda: features['targets'][:, i - 1:i, :, :])

      targets = preprocess_targets(targets, i)
      bias = decoder_self_attention_bias[:, :, i:i + 1, :i + 1]

      with tf.variable_scope("body"):
        decoder_out = self.decode(
          targets,
          cache.get("encoder_output"),
          cache.get("encoder_decoder_attention_bias"),
          bias,
          hparams,
          cache,
          nonpadding=features_to_nonpadding(features, "targets"),
          return_attn=True)
        body_outputs, attn_weights, attn_logits = decoder_out

      with tf.variable_scope(target_modality.name):
        logits = target_modality.top(body_outputs, None)

      ret = tf.squeeze(logits, axis=[1])
      return ret, cache, attn_logits

    mels = None
    heads_constraint_masks = None
    if tgt == 's':
      decoded_ids, mels, heads_constraint_masks, scores, hit_eos, encdec_attn_logits = self.run_greedy_speech(
        hparams, batch_size, decode_length, cache, symbols_to_logits_fn)
      heads_constraint_masks = heads_constraint_masks[None, :]
    else:
      decoded_ids, scores, hit_eos, encdec_attn_logits = self.run_greedy_text(
        hparams, beam_search.EOS_ID, batch_size, decode_length, 0, cache, symbols_to_logits_fn)

    encdec_attn = encdec_attn_logits

    if self._decode_hparams.get("save_attention_weights", False):
      if tgt == 's':
        # get inputs and targets length
        if self.gta:
          targets_flatten = common_layers.flatten4d3d(
            tf.transpose(features["targets"], [0, 1, 3, 2]))  # shape: (bs, target_len, mels)
        else:
          targets_flatten = decoded_ids * tf.to_float(~hit_eos[:, :, None])
        inputs_flatten = tf.to_float(common_layers.flatten4d3d(features["inputs"]))  # shape: (bs, target_len, 1)
      else:
        # get inputs and targets length
        inputs_flatten = common_layers.flatten4d3d(
          tf.transpose(features["inputs"], [0, 1, 3, 2]))  # shape: (bs, target_len, mels)
        if self.gta:
          targets_flatten = tf.to_float(common_layers.flatten4d3d(features["targets"]))  # shape: (bs, target_len, 1)
        else:
          targets_flatten = decoded_ids * tf.to_int64(~hit_eos[:, :, None])

      inputs_nonpadding = 1.0 - common_attention.embedding_to_padding(inputs_flatten)  # shape: (bs, input_len)
      targets_nonpadding = 1.0 - common_attention.embedding_to_padding(targets_flatten)  # shape: (bs, target_len)
      hit_eos = tf.cast(1.0 - targets_nonpadding, tf.bool)
      inputs_length = tf.reduce_sum(inputs_nonpadding, axis=-1)  # (bs,)
      targets_length = tf.reduce_sum(targets_nonpadding, axis=-1)  # (bs,)
      inputs_nonpadding = tf.cast(tf.expand_dims(inputs_nonpadding, 1), tf.bool)  # shape: (bs, 1, input_len)
      targets_nonpadding = tf.cast(tf.expand_dims(targets_nonpadding, 2), tf.bool)  # shape: (bs, target_len, 1)
      padding_mask = tf.cast(tf.logical_and(inputs_nonpadding, targets_nonpadding),
                             tf.float32)  # (bs, target_len, input_len)
      encdec_attn *= padding_mask[:, None, :, :]

    ret = {
      "outputs": tf.stop_gradient(decoded_ids),
      "scores": tf.stop_gradient(scores),
      "hit_eos": tf.stop_gradient(hit_eos),
      "encdec_attn": tf.stop_gradient(encdec_attn)
    }

    if mels is not None:
      ret['mels'] = mels
    if not self._is_training_at_beginning and heads_constraint_masks is not None:
      ret['heads_constraint_masks'] = heads_constraint_masks

    if self._decode_hparams.get("save_attention_weights", False):
      utt_ids = features.get("utt_id")
      utt_ids = tf.squeeze(utt_ids, 1)  # (bs,)
      ret['utt_ids'] = utt_ids
      ret['inputs_length'] = inputs_length
      ret['targets_length'] = targets_length

    tf.logging.info(f"Fast decoding...{run_type}")
    return ret

  def run_greedy_speech(self, hparams, batch_size, decode_length, cache, symbols_to_logits_fn):
    target_modality = hparams.problem_hparams.modality["targets"]
    stage_change_step = 50

    def inner_loop(i, hit_eos, stage, next_mel, decoded_mel, cache, encdec_attn_logits, attn_pos, use_masks):
      # decode one step
      ret, cache, attn_logits = symbols_to_logits_fn(next_mel, i, cache)
      next_mel, stop_logit = \
        tf.split(ret, [hparams.audio_num_mel_bins, 1], axis=-1)
      next_mel = tf.expand_dims(next_mel, axis=1)
      decoded_mel = tf.concat([decoded_mel, next_mel], axis=1)
      encdec_attn_logits = tf.concat([encdec_attn_logits, attn_logits], axis=3)
      i = i + 1

      # stop condition
      this_hit_eos = hit_eos[:, -1]
      stop_logit = tf.squeeze(stop_logit, [-1])
      if hparams.attn_constraint:
        this_hit_eos |= (attn_pos >= tf.to_int64(
          tf.reduce_sum(tf.to_float(cache["encoder_decoder_attention_bias"][:, 0, 0, :] > -1.0), -1)) - 3) \
                        & tf.greater(tf.sigmoid(stop_logit), 0.5)
      else:
        this_hit_eos |= tf.greater(tf.sigmoid(stop_logit), 0.5)
      hit_eos = tf.concat([hit_eos, this_hit_eos[:, None]], axis=1)

      if hparams.attn_constraint:
        weight_shape = tf.shape(encdec_attn_logits)
        all_prev_weights = tf.reshape(tf.nn.softmax(encdec_attn_logits, -1), [
          weight_shape[0], weight_shape[1] * weight_shape[2], weight_shape[3], weight_shape[4]
        ])  # [bs, heads, L, length_kv]

        # if the stage should change
        next_stage = tf.equal(i, stage_change_step) | tf.greater_equal(i, decode_length)
        if not self.gta:
          next_stage |= tf.reduce_all(hit_eos[:, -1])
        next_stage &= tf.equal(stage, 0)

        # choose the diagonal attention
        use_masks = tf.cond(
          next_stage,
          true_fn=lambda: tf.to_float(tf.reduce_mean(tf.reduce_max(all_prev_weights[:, :, :i], -1), [0, 2]) > 0.6),
          false_fn=lambda: use_masks)
        attn_pos = tf.cond(
          next_stage,
          true_fn=lambda: tf.zeros([batch_size], tf.int64),
          false_fn=lambda: attn_pos
        )

        # reset when the stage changes
        for layer in range(hparams.num_decoder_layers):
          cache["layer_%d" % layer]['k'] = tf.cond(
            next_stage,
            true_fn=lambda: common_attention.split_heads(
              tf.zeros([batch_size, 0, hparams.hidden_size]), hparams.num_heads),
            false_fn=lambda: cache["layer_%d" % layer]['k'])
          cache["layer_%d" % layer]['v'] = tf.cond(
            next_stage,
            true_fn=lambda: common_attention.split_heads(
              tf.zeros([batch_size, 0, hparams.hidden_size]), hparams.num_heads),
            false_fn=lambda: cache["layer_%d" % layer]['v'])
          cache["layer_%d" % layer]['f'] = tf.cond(
            next_stage,
            true_fn=lambda: tf.zeros([batch_size, 0, hparams.hidden_size]),
            false_fn=lambda: cache["layer_%d" % layer]['f'])
        encdec_attn_logits = tf.cond(
          next_stage,
          true_fn=lambda: tf.zeros(
            [batch_size, hparams.num_decoder_layers, hparams.num_heads, 0, max_input_len], dtype=tf.float32),
          false_fn=lambda: encdec_attn_logits)
        decoded_mel = tf.cond(
          next_stage,
          true_fn=lambda: tf.zeros([batch_size, 0, out_shape], dtype=tf.float32),
          false_fn=lambda: decoded_mel)
        hit_eos = tf.cond(
          next_stage,
          true_fn=lambda: tf.zeros([batch_size, 1], dtype=tf.bool),
          false_fn=lambda: hit_eos)
        next_mel = tf.cond(
          next_stage,
          true_fn=lambda: tf.zeros([batch_size, 1, out_shape], dtype=tf.float32),
          false_fn=lambda: next_mel)
        stage = tf.cond(
          next_stage,
          true_fn=lambda: stage + 1,
          false_fn=lambda: stage)
        i = tf.cond(
          next_stage,
          true_fn=lambda: 0,
          false_fn=lambda: i)

        # update the constraint mask
        prev_weights_mask1 = tf.to_float(tf.sequence_mask(
          tf.maximum(attn_pos - 1, 0), tf.shape(encdec_attn_logits)[-1]))  # [bs, L_kv]
        prev_weights_mask2 = 1.0 - tf.to_float(
          tf.sequence_mask(attn_pos + 4, tf.shape(encdec_attn_logits)[-1]))  # [bs, L_kv]
        enc_dec_attn_constraint_masks = (prev_weights_mask1 + prev_weights_mask2)[:, None, None, :] * \
                                        use_masks[None, :, None, None]
        for layer in range(hparams.num_decoder_layers):
          cache["layer_%d" % layer]['enc_dec_attn_constraint_masks'] = \
            enc_dec_attn_constraint_masks[:, layer * hparams.num_heads: (layer + 1) * hparams.num_heads]

        # update attention position
        def should_move_on():
          prev_weights = all_prev_weights  # shape: [bs, heads, L, length_kv]
          prev_weights = tf.reduce_sum(prev_weights * use_masks[None, :, None, None], 1) / tf.reduce_sum(
            use_masks)  # [bs, L, length_kv]
          move_on = tf.gather_nd(tf.reduce_mean(prev_weights[:, -3:, :], 1),
                                 tf.stack([tf.range(0, batch_size), tf.to_int32(attn_pos)], -1)) < 0.7
          move_on &= tf.argmax(prev_weights[:, -1, :], -1) > attn_pos  # shape: [bs, heads]
          return attn_pos + tf.to_int64(move_on)

        attn_pos = tf.cond(
          tf.logical_and(tf.greater(i, 3), tf.equal(stage, 1)),
          true_fn=should_move_on,
          false_fn=lambda: attn_pos
        )
      return i, hit_eos, stage, next_mel, decoded_mel, cache, encdec_attn_logits, attn_pos, use_masks

    def is_not_finished(i, hit_eos, stage, *_):
      finished = i >= decode_length
      if not self.gta:
        finished |= tf.reduce_all(hit_eos[:, -1])
      not_finished = ~finished
      if hparams.attn_constraint:
        not_finished |= tf.equal(stage, 0)
      return not_finished

    out_shape = hparams.audio_num_mel_bins
    hit_eos = tf.zeros([batch_size, 1], dtype=tf.bool)
    stage = tf.zeros([], dtype=tf.int64)
    next_mel = tf.zeros([batch_size, 1, out_shape], dtype=tf.float32)
    decoded_mel = tf.zeros([batch_size, 0, out_shape], dtype=tf.float32)
    max_input_len = common_layers.shape_list(cache["encoder_output"])[1]
    encdec_attn_logits = tf.zeros(
      [batch_size, hparams.num_decoder_layers, hparams.num_heads, 0, max_input_len], dtype=tf.float32)
    attn_pos = tf.zeros([batch_size], dtype=tf.int64)
    use_masks = tf.zeros([hparams.num_decoder_layers * hparams.num_heads], dtype=tf.float32)

    _, hit_eos, _, _, decoded_ids, _, encdec_attn_logits, _, use_masks = tf.while_loop(
      is_not_finished,
      inner_loop, [
        tf.constant(0), hit_eos, stage, next_mel, decoded_mel, cache, encdec_attn_logits, attn_pos, use_masks
      ],
      shape_invariants=[
        tf.TensorShape([]),
        tf.TensorShape([None, None]),
        tf.TensorShape([]),
        tf.TensorShape([None, None, out_shape]),
        tf.TensorShape([None, None, out_shape]),
        nest.map_structure(beam_search.get_state_shape_invariants, cache),
        tf.TensorShape([None, hparams.num_decoder_layers, hparams.num_heads, None, None]),
        tf.TensorShape([None]),
        tf.TensorShape([None])
      ])
    hit_eos = hit_eos[:, 1:]
    p = hparams
    if p.use_postnet:
      decoded_ids = target_modality.postnet(
        decoded_ids, 'postnet',
        dropout_rate=p.postnet_dropout_rate,
        kernel=p.postnet_kernel,
        postnet_channel=p.postnet_channel,
        postnet_num_layers=p.postnet_num_layers,
        output_shape=p.audio_num_mel_bins,
        is_training=False)
    mels = decoded_ids
    if p.predict_linear:
      bias = -1e8 * tf.to_float(hit_eos)  # [BS, T]
      decoded_ids = target_modality.cbhg(decoded_ids, p, bias, is_training=False)
    scores = tf.zeros([batch_size], dtype=tf.float32)

    decoded_ids *= (1.0 - tf.to_float(hit_eos))[:, :, None]
    if self.hparams.gl_on_gpu:
      tf.logging.info("GL on GPU...")
      if hparams.predict_linear:
        decoded_ids = audio.inv_linear_spectrogram_tensorflow(decoded_ids, self.hparams, hit_eos)
      else:
        decoded_ids = audio.inv_mel_spectrogram_tensorflow(decoded_ids, self.hparams, hit_eos)

    encdec_attn_logits = tf.reshape(encdec_attn_logits,
                                    [batch_size, hparams.num_decoder_layers * hparams.num_heads, -1, max_input_len])
    return decoded_ids, mels, use_masks, scores, hit_eos, encdec_attn_logits

  def run_greedy_text(self, hparams, eos_id, batch_size, decode_length, sos_id, cache, symbols_to_logits_fn):
    def inner_loop(i, hit_eos, next_id, decoded_ids, cache, encdec_attn_logits):
      """One step of greedy decoding."""
      logits, cache, attn_logits = symbols_to_logits_fn(next_id, i, cache)
      temperature = (0.0 if hparams.sampling_method == "argmax" else
                     hparams.sampling_temp)
      next_id = common_layers.sample_with_temperature(logits, temperature)

      hit_eos = tf.concat(
        [hit_eos, tf.expand_dims(hit_eos[:, -1] | tf.equal(tf.reshape(next_id, [-1]), eos_id), axis=1)], axis=1)

      decoded_ids = tf.concat([decoded_ids, next_id], axis=1)
      encdec_attn_logits = tf.concat([encdec_attn_logits, attn_logits], axis=3)
      return i + 1, hit_eos, next_id, decoded_ids, cache, encdec_attn_logits

    def is_not_finished(i, hit_eos, *_):
      finished = i >= decode_length
      if not self.gta:
        finished |= tf.reduce_all(hit_eos[:, -1])
      return tf.logical_not(finished)

    decoded_ids = tf.zeros([batch_size, 0, 1], dtype=tf.int64)
    hit_eos = tf.zeros([batch_size, 1], dtype=tf.bool)
    next_id = sos_id * tf.ones([batch_size, 1, 1], dtype=tf.int64)
    max_input_len = common_layers.shape_list(cache["encoder_output"])[1]
    encdec_attn_logits = tf.zeros(
      [batch_size, hparams.num_decoder_layers, hparams.num_heads, 0, max_input_len], dtype=tf.float32)

    _, hit_eos, _, decoded_ids, _, encdec_attn_logits = tf.while_loop(
      is_not_finished,
      inner_loop, [
        tf.constant(0), hit_eos, next_id, decoded_ids, cache, encdec_attn_logits
      ],
      shape_invariants=[
        tf.TensorShape([]),
        tf.TensorShape([None, None]),
        tf.TensorShape([None, None, 1]),
        tf.TensorShape([None, None, 1]),
        nest.map_structure(beam_search.get_state_shape_invariants, cache),
        tf.TensorShape([None, hparams.num_decoder_layers, hparams.num_heads, None, None])
      ])
    scores = tf.zeros([batch_size], dtype=tf.float32)
    hit_eos = hit_eos[:, 1:]
    encdec_attn_logits = tf.reshape(encdec_attn_logits,
                                    [batch_size, hparams.num_decoder_layers * hparams.num_heads, -1, max_input_len])
    return decoded_ids, scores, hit_eos, encdec_attn_logits

  def estimator_spec_predict(self, features, use_tpu=False):
    decode_hparams = self._decode_hparams
    infer_out = self.infer(
      features,
      beam_size=decode_hparams.beam_size,
      top_beams=(decode_hparams.beam_size
                 if decode_hparams.return_beams else 1),
      alpha=decode_hparams.alpha,
      decode_length=decode_hparams.extra_length,
      use_tpu=use_tpu)
    features = self.set_modules_and_get_features(self._hparams.run_type, features)

    outputs = infer_out["outputs"]
    mels = infer_out.get("mels", outputs)
    scores = infer_out.get("encdec_attn", infer_out.get("scores"))
    if len(common_layers.shape_list(scores)) > 3:
      if 'heads_constraint_masks' in infer_out:
        heads_constraint_masks = infer_out['heads_constraint_masks'][0]
        scores = tf.nn.softmax(scores)
        scores = tf.reduce_sum(scores * heads_constraint_masks[None, :, None, None], [1]) / tf.reduce_sum(
          heads_constraint_masks)
      else:
        scores = tf.reduce_mean(scores, [1])

    hit_eos = infer_out["hit_eos"]
    inputs = features.get("inputs")
    targets = features.get("targets")
    raw_transcript = features.get("raw_transcript")

    predictions = {
      "outputs": outputs,
      "mels": mels,
      "scores": scores,
      "hit_eos": hit_eos,
      "inputs": inputs,
      "targets": targets,
      "raw_transcript": raw_transcript,
    }

    # Pass through remaining features
    for name, feature in features.items():
      if name not in list(predictions.keys()) + ["targets"]:
        if not feature.shape.as_list():
          # All features must have a batch dimension
          batch_size = common_layers.shape_list(outputs)[0]
          feature = tf.tile(tf.expand_dims(feature, 0), [batch_size])
        predictions[name] = feature

    _del_dict_non_tensors(predictions)

    export_out = {"outputs": predictions["outputs"]}
    if "scores" in predictions:
      export_out["scores"] = predictions["scores"]
    export_out["hit_eos"] = predictions["hit_eos"]
    export_out["mels"] = predictions["mels"]
    export_out["raw_transcript"] = predictions["raw_transcript"]
    export_out["utt_id"] = features.get("utt_id", tf.constant(0, tf.int64))

    # Necessary to rejoin examples in the correct order with the Cloud ML Engine
    # batch prediction API.
    if "batch_prediction_key" in predictions:
      export_out["batch_prediction_key"] = predictions["batch_prediction_key"]

    remove_summaries()
    export_outputs = {
      tf.saved_model.signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY:
        tf.estimator.export.PredictOutput(export_out)
    }
    if use_tpu:
      return tf.contrib.tpu.TPUEstimatorSpec(
        tf.estimator.ModeKeys.PREDICT,
        predictions=predictions,
        export_outputs=export_outputs)
    else:
      return tf.estimator.EstimatorSpec(
        tf.estimator.ModeKeys.PREDICT,
        predictions=predictions,
        export_outputs=export_outputs)

  def set_targets_modality(self, modality):
    self._problem_hparams.modality["targets"] = modality

  def set_inputs_modality(self, modality):
    self._problem_hparams.modality["inputs"] = modality

  def set_modules_and_get_features(self, run_type, features=None):
    src, tgt = run_type.split("->")
    self.encoder_layer_prefix = src
    self.decoder_layer_prefix = tgt

    def get_enc_modalities(t):
      if t == 's':
        return self.speech_enc_modalities
      else:
        return self.text_modalities

    def get_dec_modalities(t):
      if t == 's':
        return self.speech_dec_modalities
      else:
        return self.text_modalities

    enc_modalities = get_enc_modalities(src)
    dec_modalities = get_dec_modalities(tgt)

    _features = {'inputs': None, 'targets': None}
    if features:
      if 'infer_targets' in features:
        features['targets'] = features['infer_targets']
      if 'targets' not in features:
        features['targets'] = None
      for k in features:
        _features[k] = features[k]

      if _features['targets'] is not None and _features['targets'].shape[-2] == 1:
        s_data = features['inputs'], features['input_space_id']
        t_data = features['targets'], features['target_space_id']
      else:
        s_data = features['targets'], features['target_space_id']
        t_data = features['inputs'], features['input_space_id']

      def get_data(t):
        if t == 's':
          return s_data
        else:
          return t_data

      _features['inputs'], _features['input_space_id'] = get_data(src)
      _features['targets'], _features['target_space_id'] = get_data(tgt)

    self.set_inputs_modality(enc_modalities)
    self.set_targets_modality(dec_modalities)

    return _features

  @staticmethod
  def train_hooks(hook_context):
    return [RecordStepHook(hook_context)]

  @staticmethod
  def expand_layer_prefix(layer_prefix):
    if layer_prefix != '' or layer_prefix is not None:
      return layer_prefix + '_'
    else:
      return ''

  def get_encoder_layer_names(self):
    return [self.expand_layer_prefix(self.encoder_layer_prefix) + 'encoder' +
            ('_no_sa' if self.hparams.no_sa else '') +
            ('_glu' if self.hparams.glu else '')] * self._hparams.num_encoder_layers

  def get_decoder_layer_names(self):
    return [self.expand_layer_prefix(self.decoder_layer_prefix) + 'decoder' +
            ('_no_sa' if self.hparams.no_sa else '') +
            ('_glu' if self.hparams.glu else '')] * self._hparams.num_decoder_layers


@registry.register_hparams
def transformer_speech():
  """HParams for training TTS model."""
  hparams = transformer_base_v3()
  hparams.add_hparam('pos_scale', True)
  hparams.add_hparam('enc_prenet', False)
  hparams.add_hparam('use_postnet', False)
  hparams.add_hparam('prenet_do', 0.5)
  hparams.add_hparam('postnet_num_layers', 3)
  hparams.add_hparam('postnet_dropout_rate', 0.5)
  hparams.add_hparam('postnet_kernel', 5)
  hparams.add_hparam('postnet_channel', 256)
  hparams.add_hparam('stop_token_weight', 5.0)
  hparams.add_hparam('plot_attention', False)
  hparams.add_hparam('predict_linear', False)
  hparams.add_hparam('run_type', 't->s')
  hparams.add_hparam('share_text_mod', False)
  hparams.add_hparam('use_cvmn', False)
  hparams.add_hparam('audio_add_delta_deltas', True)
  hparams.add_hparam('max_decoder_relative_position', None)
  hparams.add_hparam('attn_constraint', True)
  hparams.add_hparam('gl_on_gpu', True)
  hparams.add_hparam('decoder_proximity_bias', False)
  hparams.add_hparam('hybrid_heads', False)
  hparams.add_hparam('no_sa', False)
  hparams.add_hparam('glu', False)
  hparams.add_hparam('postnet_start_at', 60000)

  # cbhg
  hparams.add_hparam('cbhg_kernels', 8)
  hparams.add_hparam('cbhg_conv_channels', 512)
  hparams.add_hparam('cbhg_pool_size', 2)
  hparams.add_hparam('cbhg_projection', 512)
  hparams.add_hparam('cbhg_projection_kernel_size', 3)
  hparams.add_hparam('cbhg_highwaynet_layers', 4)
  hparams.add_hparam('cbhg_highway_units', 512)
  hparams.add_hparam('cbhg_sa_hidden', 512)

  # common
  hparams.max_length = 1240000
  hparams.max_input_seq_length = 1550
  hparams.max_target_seq_length = 1550
  hparams.num_decoder_layers = 4
  hparams.num_encoder_layers = 4
  hparams.hidden_size = 256
  hparams.daisy_chain_variables = False
  hparams.filter_size = 1024
  hparams.num_heads = 2
  hparams.ffn_layer = "conv_relu_conv"
  hparams.conv_first_kernel = 9
  hparams.weight_decay = 0
  hparams.layer_prepostprocess_dropout = 0.1
  hparams.relu_dropout = 0.1
  hparams.batch_size = 1600000
  hparams.optimizer = "MultistepAdam"
  hparams.optimizer_multistep_accumulate_steps = 1
  hparams.max_relative_position = 0
  hparams.max_decoder_relative_position = 0
  hparams.learning_rate_constant = 2.0
  hparams.clip_grad_norm = 1.0
  return hparams


@registry.register_hparams
def transformer_speech_middle():
  hparams = transformer_speech()
  hparams.hidden_size = 384
  hparams.filter_size = 1536
  hparams.batch_size = 1280000
  return hparams

@registry.register_hparams
def transformer_speech_big():
  hparams = transformer_speech()
  hparams.hidden_size = 512
  hparams.filter_size = 2048
  hparams.batch_size = 1280000
  hparams.num_encoder_layers = 6
  hparams.num_decoder_layers = 6
  return hparams


@registry.register_hparams
def transformer_speech_6l():
  hparams = transformer_speech()
  hparams.num_decoder_layers = 6
  hparams.num_encoder_layers = 6
  return hparams


@registry.register_hparams
def transformer_speech_accumulate_2steps():
  hparams = transformer_speech()
  hparams.optimizer = "MultistepAdam"
  hparams.optimizer_multistep_accumulate_steps = 2
  return hparams


def set_relative(hparams):
  # hparams.self_attention_type = 'dot_product_relative'
  hparams.max_relative_position = 10
  hparams.max_decoder_relative_position = 40

@registry.register_hparams
def transformer_speech_relative():
  hparams = transformer_speech()
  set_relative(hparams)
  return hparams


@registry.register_hparams
def transformer_speech_middle_relative():
  hparams = transformer_speech_middle()
  set_relative(hparams)
  return hparams


## ASR

@registry.register_hparams
def transformer_speech_asr():
  hparams = transformer_speech()
  hparams.add_hparam('enc_modality', 'conv')
  hparams.num_decoder_layers = 4
  hparams.num_encoder_layers = 6
  hparams.hidden_size = 384
  hparams.filter_size = 1536
  hparams.batch_size = 1600000  # 20000(max_total_mel) * 80 (num_mel_bins)
  hparams.num_heads = 2
  hparams.weight_decay = 0
  hparams.layer_prepostprocess_dropout = 0.2
  hparams.relu_dropout = 0.2
  hparams.run_type = 's->t'
  return hparams


@registry.register_hparams
def transformer_speech_asr_small():
  hparams = transformer_speech_asr()
  hparams.num_decoder_layers = 2
  hparams.num_encoder_layers = 2
  hparams.hidden_size = 256
  hparams.filter_size = 1024
  hparams.batch_size = 800000  # 20000(max_total_mel) * 80 (num_mel_bins)
  hparams.layer_prepostprocess_dropout = 0.1
  hparams.relu_dropout = 0.1
  return hparams


@registry.register_hparams
def transformer_speech_asr_relative():
  hparams = transformer_speech_asr()
  hparams.self_attention_type = 'dot_product_relative'
  hparams.max_relative_position = 20
  return hparams
