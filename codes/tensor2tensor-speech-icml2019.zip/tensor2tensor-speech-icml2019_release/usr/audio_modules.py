import tensorflow as tf

from tensor2tensor.layers import common_layers, common_attention, common_audio
from tensor2tensor.layers.common_attention import multihead_attention
from tensor2tensor.layers.modalities import SymbolModality
from tensor2tensor.utils import modality


def conv1d(inputs, kernel_size, channels, activation, is_training, drop_rate, scope):
  with tf.variable_scope(scope):
    conv1d_output = tf.layers.conv1d(
      inputs,
      filters=channels,
      kernel_size=kernel_size,
      activation=None,
      padding='same')
    conv1d_output = tf.contrib.layers.batch_norm(conv1d_output, is_training=is_training, updates_collections=None)
    activated = activation(conv1d_output)
    return tf.layers.dropout(activated, rate=drop_rate, training=is_training,
                             name='dropout_{}'.format(scope))


class HighwayNet:
  def __init__(self, units, name=None):
    self.units = units
    self.scope = 'HighwayNet' if name is None else name

    self.H_layer = tf.layers.Dense(units=self.units, activation=tf.nn.relu, name='H')
    self.T_layer = tf.layers.Dense(units=self.units, activation=tf.nn.sigmoid, name='T',
                                   bias_initializer=tf.constant_initializer(-1.))

  def __call__(self, inputs):
    with tf.variable_scope(self.scope):
      H = self.H_layer(inputs)
      T = self.T_layer(inputs)
      return H * T + inputs * (1. - T)


class CBHG:
  def __init__(self, hparams, K, conv_channels, pool_size, projections, projection_kernel_size, n_highwaynet_layers,
               highway_units, hidden, is_training, name=None):
    self.hparams = hparams
    self.K = K
    self.conv_channels = conv_channels
    self.pool_size = pool_size

    self.projections = projections
    self.projection_kernel_size = projection_kernel_size

    self.is_training = is_training
    self.scope = 'CBHG' if name is None else name

    self.highway_units = highway_units
    self.highwaynet_layers = [
      HighwayNet(highway_units, name='{}_highwaynet_{}'.format(self.scope, i + 1))
      for i in range(n_highwaynet_layers)]
    self.hidden = hidden
    # self._fw_cell = tf.nn.rnn_cell.GRUCell(rnn_units, name='{}_forward_RNN'.format(self.scope))
    # self._bw_cell = tf.nn.rnn_cell.GRUCell(rnn_units, name='{}_backward_RNN'.format(self.scope))

  def __call__(self, inputs, bias):
    with tf.variable_scope(self.scope):
      with tf.variable_scope('conv_bank'):
        # Convolution bank: concatenate on the last axis to stack channels from all convolutions
        # The convolution bank uses multiple different kernel sizes to have many insights of the input sequence
        # This makes one of the strengths of the CBHG block on sequences.
        conv_outputs = tf.concat(
          [conv1d(inputs, k, self.conv_channels, tf.nn.relu, self.is_training, 0., 'conv1d_{}'.format(k)) for k in
           range(1, self.K + 1)],
          axis=-1
        )

      # Maxpooling (dimension reduction, Using max instead of average helps finding "Edges" in mels)
      maxpool_output = tf.layers.max_pooling1d(
        conv_outputs,
        pool_size=self.pool_size,
        strides=1,
        padding='same')

      # Two projection layers
      proj1_output = conv1d(maxpool_output, self.projection_kernel_size, self.projections[0], tf.nn.relu,
                            self.is_training, 0., 'proj1')
      proj2_output = conv1d(proj1_output, self.projection_kernel_size, self.projections[1], lambda _: _,
                            self.is_training, 0., 'proj2')

      # Residual connection
      highway_input = proj2_output + inputs

      # Additional projection in case of dimension mismatch (for HighwayNet "residual" connection)
      if highway_input.shape[2] != self.highway_units:
        highway_input = tf.layers.dense(highway_input, self.highway_units)

      # 4-layer HighwayNet
      for highwaynet in self.highwaynet_layers:
        highway_input = highwaynet(highway_input)

      bias = bias[:, None, None, :]
      # outputs = multihead_attention(highway_input,
      #                               None,
      #                               bias,
      #                               self.hidden,
      #                               self.hidden,
      #                               self.hidden,
      #                               1,
      #                               0.0,
      #                               name="multihead_attention",
      #                               make_image_summary=False)
      # outputs = tf.layers.dense(outputs, self.hidden)
      # outputs = tf.nn.tanh(outputs) + highway_input

      x = highway_input
      for i in range(2):
        with tf.variable_scope(f'cbhg_self_attention_{i}'):
          # self-attn
          y = multihead_attention(common_layers.layer_norm(x),
                                  None,
                                  bias,
                                  self.hidden,
                                  self.hidden,
                                  self.hidden,
                                  1,
                                  0.0,
                                  name="multihead_attention",
                                  make_image_summary=False)
          x = tf.layers.dropout(y, self.hparams.layer_prepostprocess_dropout) + x
          # ffn
          y = tf.layers.dense(common_layers.layer_norm(x), self.hidden)
          y = tf.nn.relu(y)
          y = tf.layers.dense(y, self.hidden)
          x = tf.layers.dropout(y, self.hparams.layer_prepostprocess_dropout) + x

      return x


class SpeechSymbolModality(SymbolModality):

  def __init__(self, model_hparams, vocab_size=None, name='txt_modality', target_prenet=False):
    self._name = name
    self.target_prenet = target_prenet
    super(SymbolModality, self).__init__(model_hparams, vocab_size)

  @property
  def name(self):
    return self._name

  def bottom(self, x):
    x = self.bottom_simple(x, "shared", reuse=tf.AUTO_REUSE)
    p = self._model_hparams
    if p.enc_prenet:
      x = self.prenet(x)
    return x

  def prenet(self, x):
    p = self._model_hparams
    with tf.variable_scope("shared", reuse=tf.AUTO_REUSE):
      mask = tf.to_float(tf.not_equal(tf.reduce_sum(x, -1, keepdims=True), 0))
      x = tf.squeeze(x, 2)
      is_training = p.mode == tf.estimator.ModeKeys.TRAIN
      for i in range(2):
        x = tf.layers.conv1d(x, p.hidden_size, 5, padding='same', use_bias=True, activation=tf.nn.relu)
        x = common_layers.layer_norm(x)
        x *= mask[:, :, 0, :]
        x = tf.layers.dropout(x, p.prenet_do, training=is_training)

      x = tf.layers.dense(x, p.hidden_size,
                          use_bias=False, activation=tf.nn.relu,
                          name='dense_final')
      x = x[:, :, None, :]
      x *= mask
    return x

  def targets_bottom(self, x):
    x = self.bottom_simple(x, "shared", reuse=tf.AUTO_REUSE)
    if self.target_prenet:
      x = self.prenet(x)
    return x

  def top(self, body_output, _):
    """Generate logits.

    Args:
      body_output: A Tensor with shape [batch, p0, p1, body_input_depth]
    Returns:
      logits: A Tensor with shape  [batch, p0, p1, ?, vocab_size].
    """
    if self._model_hparams.symbol_modality_skip_top:
      return tf.expand_dims(body_output, 3)

    if self._model_hparams.shared_embedding_and_softmax_weights:
      scope_name = "shared"
      reuse = tf.AUTO_REUSE
    else:
      scope_name = "softmax"
      reuse = False

    with tf.variable_scope(scope_name, reuse=reuse):
      body_output_shape = common_layers.shape_list(body_output)
      var = self._get_weights(body_output_shape[-1])
      if (self._model_hparams.factored_logits and
          self._model_hparams.mode == tf.estimator.ModeKeys.TRAIN):
        # insert channels dimension
        body_output = tf.expand_dims(body_output, 3)
        return common_layers.FactoredTensor(body_output, var)
      else:
        body_output = tf.reshape(body_output, [-1, body_output_shape[-1]])
        logits = tf.matmul(body_output, var, transpose_b=True)
        if (common_layers.is_xla_compiled() and
            self._model_hparams.mode == tf.estimator.ModeKeys.TRAIN):
          # TPU does not react kindly to extra dimensions.
          # TODO(noam): remove this once TPU is more forgiving of extra dims.
          return logits
        else:
          return tf.reshape(logits,
                            body_output_shape[:-1] + [1, self._vocab_size])


class TTSModality(modality.Modality):
  """Common tts processing."""

  def __init__(self, model_hparams, vocab_size=None, name='speech_modality'):
    self._name = name
    super(TTSModality, self).__init__(model_hparams, vocab_size)

  @property
  def name(self):
    return self._name

  def _bottom(self, x, is_training=True):
    p = self._model_hparams

    x = tf.squeeze(x, axis=-1)
    mask = tf.to_float(tf.not_equal(tf.reduce_sum(tf.abs(x), -1, keepdims=True), 0))

    if p.predict_linear and x.shape[-1] > p.audio_num_mel_bins:
      x, _ = tf.split(x, [p.audio_num_mel_bins, p.num_freq], axis=-1)

    with tf.variable_scope(self.name, reuse=tf.AUTO_REUSE):
      for i in range(2):
        x = tf.layers.dense(x, p.hidden_size, use_bias=True, activation=tf.nn.relu, name='dense%d' % i)
        x = tf.layers.dropout(x, p.prenet_do, training=is_training)
      x = tf.layers.dense(x, p.hidden_size,
                          use_bias=False, activation=tf.nn.relu,
                          name='dense_final')

      x = x * mask
      return tf.expand_dims(x, axis=2)

  def targets_bottom(self, x):
    return self._bottom(x, True)

  def bottom(self, x):
    return self._bottom(x, self._model_hparams.mode == tf.estimator.ModeKeys.TRAIN)

  def top(self, body_output, _):
    with tf.variable_scope(self.name, reuse=tf.AUTO_REUSE):
      p = self._model_hparams
      softmax_matrix = tf.get_variable("mel_softmax", [p.audio_num_mel_bins + 1, p.hidden_size],
                                       initializer=tf.random_normal_initializer(0.0, p.hidden_size ** -0.5))
      decoder_out = common_layers.FactoredTensor(body_output, softmax_matrix)
      # """Compute loss numerator and denominator for one shard of output."""
      # shape before: top_out:[1 1444 1 81] targets: [1 1444 80 1]
      decoder_out = tf.squeeze(decoder_out, axis=[-2]) # [bs, target_len, 81]
      return decoder_out

  def postnet(self, x, scope, output_shape=80, is_training=True,
              dropout_rate=0.5, postnet_num_layers=5,
              postnet_channel=512, kernel=5):
    old_ = x
    with tf.variable_scope(scope, reuse=tf.AUTO_REUSE):
      for i in range(postnet_num_layers - 1):
        x = conv1d(x, kernel, postnet_channel, tf.nn.tanh, is_training,
                   dropout_rate, 'conv_layer_{}_'.format(i + 1) + scope)
      x = conv1d(x, kernel, postnet_channel, lambda y: y, is_training,
                 dropout_rate, 'conv_layer_{}_'.format(postnet_num_layers) + scope)
      x = tf.layers.Dense(units=output_shape, name='projection_{}'.format(scope))(x)
      x = old_ + x
    return x

  def cbhg(self, post_outputs, p, bias, is_training=True):
    # Add post-processing CBHG. This does a great job at extracting features from mels before projection to Linear specs.
    # [batch_size, decoder_steps(mel_frames), cbhg_channels]
    post_outputs = CBHG(p, p.cbhg_kernels, p.cbhg_conv_channels, p.cbhg_pool_size,
                        [p.cbhg_projection, p.audio_num_mel_bins],
                        p.cbhg_projection_kernel_size, p.cbhg_highwaynet_layers,
                        p.cbhg_highway_units, p.cbhg_sa_hidden, is_training, name='CBHG_postnet')(post_outputs, bias)

    # Linear projection of extracted features to make linear spectrogram
    linear_outputs = tf.layers.Dense(p.num_freq, name='cbhg_linear_specs_projection')(post_outputs)
    return linear_outputs

  def loss(self, top_out, targets, weights_fn=None, use_extra=True):
    # top_out: [BS, T, mel_bins]
    # targets: [BS, T, mel_bins, 1]

    p = self._model_hparams
    mel_targets = tf.squeeze(targets, axis=[-1])
    if p.predict_linear and use_extra:
      mel_targets, linear_targets = tf.split(mel_targets, [p.audio_num_mel_bins, p.num_freq], axis=-1)
    else:
      mel_targets = mel_targets[..., :p.audio_num_mel_bins]

    top_outputs, stop_logit_prediction = tf.split(
      top_out, [p.audio_num_mel_bins, 1],
      axis=-1)

    if weights_fn is None:
      weights = self.weights_nonzero_speech(mel_targets)
    else:
      weights = self.weights_nonzero_speech(mel_targets) * weights_fn(mel_targets)
    decoder_loss = tf.losses.mean_squared_error(mel_targets, top_outputs, weights=weights)

    seq_mask, stop_mask = self.make_stop_target(mel_targets)

    stop_token_weight = p.stop_token_weight
    if p.get("remove_stop_token_loss") is True:
      stop_loss = 0.0
    else:
      stop_loss = tf.reduce_sum(
        tf.nn.weighted_cross_entropy_with_logits(targets=stop_mask, logits=tf.squeeze(stop_logit_prediction, axis=[-1]),
                                                 pos_weight=stop_token_weight) * seq_mask)
      stop_loss = stop_loss / (
          tf.reduce_sum(seq_mask) + tf.to_float(tf.shape(mel_targets)[0]) * tf.constant(stop_token_weight - 1))

    postnet_loss = tf.constant(0, dtype=tf.float32)
    p = self._model_hparams
    if p.use_postnet and use_extra:
      top_outputs = self.postnet(top_outputs, 'postnet',
                                 dropout_rate=p.postnet_dropout_rate,
                                 kernel=p.postnet_kernel,
                                 postnet_channel=p.postnet_channel,
                                 postnet_num_layers=p.postnet_num_layers,
                                 output_shape=p.audio_num_mel_bins,
                                 is_training=True)
      postnet_loss = tf.losses.mean_squared_error(
        mel_targets, top_outputs,
        weights=self.weights_nonzero_speech(mel_targets))

    linear_loss = tf.constant(0, dtype=tf.float32)
    if p.predict_linear and use_extra:
      bias = -1e8 * (1. - tf.to_float(tf.not_equal(tf.reduce_sum(tf.abs(mel_targets), axis=-1), 0)))  # [BS, T]
      linear_outputs = self.cbhg(top_outputs, p, bias, is_training=True)
      linear_loss = tf.losses.mean_squared_error(
        linear_targets, linear_outputs,
        weights=self.weights_nonzero_speech(linear_targets))

    return [decoder_loss, postnet_loss, linear_loss, stop_loss], tf.constant(1, dtype=tf.float32)

  def make_stop_target(self, labels):
    """
    :param seq_length: [N,]
    :return:
    """
    seq_mask = tf.to_float(tf.not_equal(tf.reduce_sum(tf.abs(labels), axis=-1), 0))
    seq_length = tf.reduce_sum(seq_mask, axis=1)
    mask_r = 1 - tf.sequence_mask(seq_length - 1, tf.shape(labels)[1], tf.float32)
    return seq_mask, mask_r

  def weights_nonzero_speech(self, labels):
    """Assign weight 1.0 to all labels except for padding (id=0)."""
    channel = tf.shape(labels)[-1]
    return tf.tile(tf.to_float(tf.not_equal(tf.reduce_sum(tf.abs(labels), axis=-1, keep_dims=True), 0)),
                   [1, 1, channel])

  def _get_weights(self, hidden_dim=None):
    """Create or get concatenated embedding or softmax variable.

    Args:
      hidden_dim: dim of the variable. Defaults to self._body_input_depth

    Returns:
       a list of self._num_shards Tensors.
    """
    with tf.variable_scope('shared'):
      if hidden_dim is None:
        hidden_dim = self._body_input_depth
      num_shards = self._model_hparams.symbol_modality_num_shards
      shards = []
      for i in range(num_shards):
        shard_size = (43 // num_shards) + (
          1 if i < 43 % num_shards else 0)
        var_name = "weights_%d" % i
        shards.append(
          tf.get_variable(
            var_name, [shard_size, hidden_dim],
            initializer=tf.random_normal_initializer(0.0, hidden_dim ** -0.5)))
      if num_shards == 1:
        ret = shards[0]
      else:
        ret = tf.concat(shards, 0)
      # Convert ret to tensor.
      if not tf.contrib.eager.in_eager_mode():
        ret = common_layers.convert_gradient_to_tensor(ret)
      return ret


class SpeechRecognitionModality(modality.Modality):
  """Common ASR filterbank processing."""

  def bottom(self, x):
    """Use batchnorm instead of CMVN and shorten the stft with strided convs.

    Args:
      x: float32 tensor with shape [batch_size, len, 1, freqs * channels]

    Returns:
      float32 tensor with shape [batch_size, shorter_len, 1, hidden_size]
    """
    p = self._model_hparams

    num_mel_bins = p.audio_num_mel_bins
    num_channels = 1

    if p.audio_add_delta_deltas:
      x = common_audio.add_delta_deltas(x)
      num_channels = 3

    x = tf.reshape(x,
                   common_layers.shape_list(x)[:2] +
                   [num_mel_bins, num_channels])

    if p.use_cvmn:
      nonpadding_mask = 1. - common_attention.embedding_to_padding(x)
      num_of_nonpadding_elements = tf.reduce_sum(
        nonpadding_mask) * num_mel_bins * num_channels

      # This replaces CMVN estimation on data
      var_epsilon = 1e-09
      mean = tf.reduce_sum(
        x, axis=[1], keepdims=True) / num_of_nonpadding_elements
      variance = (num_of_nonpadding_elements * mean ** 2. -
                  2. * mean * tf.reduce_sum(x, axis=[1], keepdims=True) +
                  tf.reduce_sum(x ** 2, axis=[1], keepdims=True)
                  ) / num_of_nonpadding_elements
      x = (x - mean) * tf.rsqrt(variance + var_epsilon) * tf.expand_dims(
        nonpadding_mask, -1)

    with tf.variable_scope(self.name, reuse=tf.AUTO_REUSE):

      # The convention is that the models are flattened along the spatial,
      # dimensions, thus the speech preprocessor treats frequencies and
      # channels as image colors (last axis)
      x.set_shape([None, None, num_mel_bins, num_channels])

      # TODO(chorowski): how to specify bottom's hparams and avoid hardcoding?
      x = tf.pad(x, [[0, 0], [0, 8], [0, 0], [0, 0]])
      for _ in range(2):
        x = tf.layers.conv2d(
          x, 256, (3, 3), (2, 2), use_bias=False)
        x = common_layers.layer_norm_ignore_padding(x)
        x = tf.nn.relu(x)  # shape: [bs, ((len_old+7)//2-1)//2, ?, ?]

      xshape = common_layers.shape_list(x)
      # apply a conv that will remove all frequencies and at the same time
      # project the output into desired hidden_size
      x = tf.pad(x, [[0, 0], [0, 2], [0, 0], [0, 0]])
      x = tf.layers.conv2d(x, p.hidden_size, (3, xshape[2]), use_bias=False)

      assert common_layers.shape_list(x)[2] == 1
      x = common_layers.layer_norm_ignore_padding(x)
      x = tf.nn.relu(x)
    return x
