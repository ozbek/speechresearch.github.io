from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf

from tensor2tensor.utils.t2t_model import log_info

FLAGS = tf.flags.FLAGS


class RecordStepHook(tf.train.SessionRunHook):
  def __init__(self, context):
    self._start_step = None

  def begin(self):
    self._global_step_tensor = tf.train.get_global_step()

  def after_create_session(self, session, coord):
    if self._start_step is None:
      self._start_step = session.run(self._global_step_tensor)

  def before_run(self, run_context):
    return tf.train.SessionRunArgs([self._global_step_tensor])

  def after_run(self, run_context, run_values):
    from usr.speech_problem import SpeechProblem
    global_step = run_values.results[0]
    SpeechProblem.runtime_global['steps'] = global_step


class RestoreTeacherHook(tf.train.SessionRunHook):
  def __init__(self, context):
    self.context = context
    self.hparams = context.hparams

  def begin(self):
    model_dir = self.hparams.get("model_dir", None)
    ckpt_dir = self.hparams.get("teacher_dir", '')
    skip_loading_teacher = (
        model_dir and tf.train.latest_checkpoint(model_dir) is not None or ckpt_dir == '')
    if skip_loading_teacher:
      return

    reader = tf.contrib.framework.load_checkpoint(ckpt_dir)
    variable_map = {}
    for var in tf.contrib.framework.get_trainable_variables():
      var_name = var.name.split(":")[0][3:]
      is_encoder_params = 'encoder' in var_name or 'txt_modality' in var_name
      if is_encoder_params and reader.has_tensor(var_name):
        log_info("Loading variable from checkpoint: %s", var_name)
        variable_map[var_name] = var
    tf.train.init_from_checkpoint(ckpt_dir, variable_map)
