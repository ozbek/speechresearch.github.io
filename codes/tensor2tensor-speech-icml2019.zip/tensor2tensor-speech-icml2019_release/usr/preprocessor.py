import os
from concurrent.futures import ProcessPoolExecutor
from functools import partial

import librosa
import numpy as np
from usr import audio


def build_from_path(hparams, input_dirs, mel_dir, linear_dir, wav_dir, n_jobs=12, tqdm=lambda x: x):
  """
    Preprocesses the speech dataset from a gven input path to given output directories

    Args:
        - hparams: hyper parameters
        - input_dir: input directory that contains the files to prerocess
        - mel_dir: output directory of the preprocessed speech mel-spectrogram dataset
        - linear_dir: output directory of the preprocessed speech linear-spectrogram dataset
        - wav_dir: output directory of the preprocessed speech audio dataset
        - n_jobs: Optional, number of worker process to parallelize across
        - tqdm: Optional, provides a nice progress bar

    Returns:
        - A list of tuple describing the train examples. this should be written to train.txt
    """

  # We use ProcessPoolExecutor to parallelize across processes, this is just for
  # optimization purposes and it can be omited
  executor = ProcessPoolExecutor(max_workers=n_jobs)
  futures = []
  index = 1
  for input_dir in input_dirs:
    with open(os.path.join(input_dir, 'metadata.csv'), encoding='utf-8') as f:
      for line in f:
        parts = line.strip().split('|')
        basename = parts[0]
        wav_path = os.path.join(input_dir, 'wavs', '{}.wav'.format(basename))
        text = parts[2]
        futures.append(
          executor.submit(
            partial(_process_utterance, mel_dir, linear_dir, wav_dir, basename, wav_path, text, hparams)))
        index += 1

  return [future.result() for future in tqdm(futures) if future.result() is not None]


def _process_utterance(wav_path, hparams, linear=True, audio_aug=False):
  """
    Preprocesses a single utterance wav/text pair

    this writes the mel scale spectogram to disk and return a tuple to write
    to the train.txt file

    Args:
        - mel_dir: the directory to write the mel spectograms into
        - linear_dir: the directory to write the linear spectrograms into
        - wav_dir: the directory to write the preprocessed wav into
        - index: the numeric index to use in the spectogram filename
        - wav_path: path to the audio file containing the speech input
        - text: text spoken in the input audio file
        - hparams: hyper parameters

    Returns:
        - A tuple: (audio_filename, mel_filename, linear_filename, time_steps, mel_frames, linear_frames, text)
    """
  try:
    # Load the audio as numpy array
    wav = audio.load_wav(wav_path, sr=hparams.audio_sample_rate)
  except FileNotFoundError:  # catch missing wav exception
    print('file {} present in csv metadata is not present in wav folder. skipping!'.format(
      wav_path))
    return None

  def get_out_mel_and_linear(wav):
    out = wav
    constant_values = 0.
    # M-AILABS extra silence specific
    if hparams.trim_silence:
      wav = audio.trim_silence(wav, hparams)

    preem_wav = audio.preemphasis(wav, hparams.preemphasis, hparams.preemphasize)

    # rescale wav
    if hparams.rescale:
      wav = wav / np.abs(wav).max() * hparams.rescaling_max
      preem_wav = preem_wav / np.abs(preem_wav).max() * hparams.rescaling_max

      # Assert all audio is in [-1, 1]
      if (wav > 1.).any() or (wav < -1.).any():
        raise RuntimeError('wav has invalid value: {}'.format(wav_path))
      if (preem_wav > 1.).any() or (preem_wav < -1.).any():
        raise RuntimeError('wav has invalid value: {}'.format(wav_path))

    # Compute the mel scale spectrogram from the wav
    mel_spectrogram = audio.melspectrogram(preem_wav, hparams).astype(np.float32)
    mel_frames = mel_spectrogram.shape[1]

    # if mel_frames > hparams.max_mel_frames and hparams.clip_mels_length:
    #   return None

    # Compute the linear scale spectrogram from the wav
    if linear:
      linear_spectrogram = audio.linearspectrogram(preem_wav, hparams).astype(np.float32)
      # linear_frames = linear_spectrogram.shape[1]
      # sanity check
      # assert linear_frames == mel_frames
    else:
      linear_spectrogram = None

    if hparams.use_lws:
      # Ensure time resolution adjustement between audio and mel-spectrogram
      fft_size = hparams.n_fft if hparams.win_size is None else hparams.win_size
      l, r = audio.pad_lr(wav, fft_size, audio.get_hop_size(hparams))

      # Zero pad audio signal
      out = np.pad(out, (l, r), mode='constant', constant_values=constant_values)
    else:
      # Ensure time resolution adjustement between audio and mel-spectrogram
      l_pad, r_pad = audio.librosa_pad_lr(wav, hparams.n_fft, audio.get_hop_size(hparams), 1)

      # Reflect pad audio signal (Just like it's done in Librosa to avoid frame inconsistency)
      out = np.pad(out, (l_pad, r_pad), mode='constant', constant_values=constant_values)

    assert len(out) >= mel_frames * audio.get_hop_size(hparams)

    # time resolution adjustement
    # ensure length of raw audio is multiple of hop size so that we can use
    # transposed convolution to upsample
    out = out[:mel_frames * audio.get_hop_size(hparams)]
    assert len(out) % audio.get_hop_size(hparams) == 0

    return out, mel_spectrogram, linear_spectrogram

  if not audio_aug:
    return get_out_mel_and_linear(wav)
  else:
    wav_11 = librosa.effects.time_stretch(wav, 1.1)
    wav_09 = librosa.effects.time_stretch(wav, 0.9)
    outs = []
    mels = []
    linears = []
    for w in [wav, wav_09, wav_11]:
      o, m, l = get_out_mel_and_linear(w)
      outs.append(o)
      mels.append(m)
      linears.append(l)
    return outs, mels, linears
