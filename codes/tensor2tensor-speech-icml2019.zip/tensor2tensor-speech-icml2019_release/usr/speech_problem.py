import functools
import os
import re

import numpy as np
import tensorflow as tf

from tensor2tensor.data_generators import audio_encoder
from tensor2tensor.data_generators import problem
from tensor2tensor.data_generators.problem import _summarize_features, pad_batch, standardize_shapes, cpu_count
from tensor2tensor.data_generators.speech_recognition import ByteTextEncoderWithEos
from tensor2tensor.utils import data_reader
from usr import audio
from usr.audio_modules import SpeechSymbolModality, TTSModality
from usr.preprocessor import _process_utterance


class SpeechProblem(problem.Problem):
  """Base class for tts problems."""

  runtime_global = {
    'steps': 0
  }

  ##########################
  #    Generation Begin
  ##########################
  @property
  def input_space_id(self):
    return problem.SpaceID.EN_CHR

  @property
  def target_space_id(self):
    return problem.SpaceID.AUDIO_SPECTRAL

  @property
  def num_shards(self):
    return 10

  @property
  def use_subword_tokenizer(self):
    return False

  @property
  def num_dev_shards(self):
    return 1

  @property
  def num_test_shards(self):
    return 1

  @property
  def use_train_shards_for_dev(self):
    """If true, we only generate training data and hold out shards for dev."""
    return True

  @staticmethod
  def clean(txt):
    s = ''.join(letter for letter in txt.lower() if 'a' <= letter <= 'z' or letter in [' '])
    s = re.sub('\s+', ' ', s).strip()
    return s

  def hparams(self, defaults=None, model_hparams=None):
    if model_hparams is None:
      model_hparams = tf.contrib.training.HParams()
    self.model_hparams = model_hparams
    self.model_hparams.add_hparam("audio_num_mel_bins", 80)
    self.model_hparams.add_hparam("num_freq", 513)
    self.model_hparams.add_hparam("symbol_size", 256)
    if defaults:
      defaults.modality = {"inputs": SpeechSymbolModality,
                           "targets": TTSModality}
      defaults.vocab_size = {"inputs": 256,
                             "targets": None}

  def feature_encoders(self, _):
    return {
      "inputs": ByteTextEncoderWithEos(),
      "waveforms": audio_encoder.AudioEncoder(),
      "targets": audio_encoder.AudioEncoder(),
    }

  @staticmethod
  def process_wav(raw_data_dir, media_file, model_hparams, linear=True, audio_aug=False):
    media_file = os.path.join(raw_data_dir, 'wavs', media_file + '.wav')
    wav_data, mel_data, linear_data = _process_utterance(media_file, model_hparams, linear=linear, audio_aug=audio_aug)
    return wav_data, mel_data, linear_data

  @staticmethod
  def mel2wav(dir, name, hparams, mel=None, linear=None):
    os.makedirs(dir, exist_ok=True)
    if mel is not None:
      wav = audio.inv_mel_spectrogram(mel, hparams)
      audio.save_wav(wav, os.path.join(dir, 'wav-{}-mel.wav'.format(name)),
                     sr=hparams.audio_sample_rate)
    if linear is not None:
      wav = audio.inv_linear_spectrogram(linear, hparams)
      audio.save_wav(wav, os.path.join(dir, 'wav-{}-linear.wav'.format(name)),
                     sr=hparams.audio_sample_rate)

  def example_reading_spec(self):
    data_fields = {
      "inputs": tf.VarLenFeature(tf.int64),
      "mel_data": tf.VarLenFeature(tf.float32),
      "utt_id": tf.VarLenFeature(tf.int64),
      "raw_transcript": tf.FixedLenFeature([], tf.string),
    }

    data_items_to_decoders = None
    return data_fields, data_items_to_decoders

  ##########################
  #    Generation End
  ##########################

  def preprocess_example(self, example, mode, hparams):
    if 'raw_transcript' in example:
      if mode == tf.estimator.ModeKeys.TRAIN:
        del example['raw_transcript']
      else:
        def str2int(s):
          ret = [int(x) for x in s]
          return [ret]

        example['raw_transcript'] = tf.py_func(str2int, [example['raw_transcript']], tf.int64)
        example['raw_transcript'].set_shape([None])

    example["targets"] = self.process_mel(hparams, example.pop('mel_data'))
    if "linear_data" in example:
      example['linear_data'] = self.process_linear(hparams, example['linear_data'])
      if hparams.predict_linear:
        example["targets"] = tf.concat([example["targets"], example.pop('linear_data')], 1)
    if mode == tf.estimator.ModeKeys.TRAIN:
      example["inputs"] = example["inputs"][:350]
      example["targets"] = example["targets"][:1550]  # mel

    return example

  @staticmethod
  def process_mel(hparams, mel_fbanks):
    return tf.reshape(mel_fbanks, [-1, hparams.audio_num_mel_bins, 1])

  @staticmethod
  def process_linear(hparams, linear):
    return tf.reshape(linear, [-1, hparams.num_freq, 1])

  def dataset(self,
              mode,
              data_dir=None,
              num_threads=None,
              output_buffer_size=None,
              shuffle_files=None,
              hparams=None,
              preprocess=True,
              dataset_split=None,
              shard=None,
              partition_id=0,
              num_partitions=1,
              shuffle_buffer_size=1024,
              max_records=-1,
              only_last=False):
    ds = super().dataset(mode, data_dir,
                         num_threads,
                         output_buffer_size,
                         shuffle_files,
                         hparams,
                         preprocess,
                         dataset_split,
                         shard,
                         partition_id,
                         num_partitions,
                         shuffle_buffer_size,
                         max_records,
                         only_last)
    if mode == tf.estimator.ModeKeys.TRAIN:
      ds = ds.repeat()
    return ds

  def input_fn(self,
               mode,
               hparams,
               data_dir=None,
               params=None,
               config=None,
               force_repeat=False,
               prevent_repeat=False,
               dataset_kwargs=None,
               batch_shuffle_size=32):
    partition_id, num_partitions = self._dataset_partition(mode, config)

    is_training = mode == tf.estimator.ModeKeys.TRAIN
    num_threads = cpu_count()

    if config and hasattr(config,
                          "data_parallelism") and config.data_parallelism:
      num_shards = config.data_parallelism.n
    else:
      num_shards = 1

    max_length = self.max_length(hparams)

    def gpu_valid_size(example):
      drop_long_sequences = is_training or hparams.eval_drop_long_sequences
      return data_reader.example_valid_size(example, hparams.min_length,
                                            max_length
                                            if drop_long_sequences else 10 ** 9)

    def define_shapes(example):
      batch_size = config and config.use_tpu and params["batch_size"]
      return standardize_shapes(example, batch_size=batch_size)

    # Read and preprocess
    data_dir = data_dir or (hasattr(hparams, "data_dir") and hparams.data_dir)

    dataset_kwargs = dataset_kwargs or {}
    dataset_kwargs.update({
      "mode": mode,
      "data_dir": data_dir,
      "num_threads": num_threads,
      "hparams": hparams,
      "partition_id": partition_id,
      "num_partitions": num_partitions,
      "shuffle_buffer_size": 128
    })

    dataset = self.dataset(**dataset_kwargs)
    dataset = dataset.map(
      data_reader.cast_ints_to_int32, num_parallel_calls=num_threads)

    # batch_size means tokens per datashard
    dataset = dataset.filter(gpu_valid_size)
    batching_scheme = data_reader.hparams_to_batching_scheme(
      hparams,
      shard_multiplier=num_shards,
      length_multiplier=self.get_hparams().batch_size_multiplier)

    dataset = dataset.apply(
      tf.contrib.data.bucket_by_sequence_length(
        data_reader.example_length, batching_scheme["boundaries"],
        batching_scheme["batch_sizes"]))

    if not is_training:
      dataset = dataset.map(
        functools.partial(pad_batch, batch_multiple=num_shards),
        num_parallel_calls=num_threads)

    dataset = dataset.map(define_shapes, num_parallel_calls=num_threads)

    if is_training and batch_shuffle_size:
      dataset = dataset.shuffle(batch_shuffle_size)

    def prepare_for_output(example):
      if not config or not config.use_tpu:
        _summarize_features(example, num_shards)
      if mode == tf.estimator.ModeKeys.PREDICT:
        if "targets" in example:
          example["infer_targets"] = example["targets"]
        return example
      else:
        return example, example.get("targets", tf.zeros(0))

    dataset = dataset.map(prepare_for_output, num_parallel_calls=num_threads)
    dataset = dataset.prefetch(2)

    if mode == tf.estimator.ModeKeys.PREDICT:
      tf.add_to_collection(tf.GraphKeys.QUEUE_RUNNERS,
                           data_reader.DummyQueueRunner())

    return dataset

  @property
  def decode_hooks(self):
    flags = tf.flags
    FLAGS = flags.FLAGS

    from usr.speech_model import SpeechModel
    def save_id2attn(decode_args):
      if SpeechModel.id2attn is not None:
        path = os.path.join(FLAGS.output_dir, "encdec_attn_weights.npz")
        if os.path.exists(path):
          id2attn = dict(np.load(path).items())
        else:
          id2attn = {}
        print(">>> old id2attn: ", len(id2attn.keys()))
        id2attn.update(SpeechModel.id2attn)
        with open(path, 'wb') as f:
          np.savez(f, **id2attn)
      return None

    def save_id2outputs(decode_args):
      if SpeechModel.id2outputs is not None:
        path = os.path.join(FLAGS.output_dir, "outputs.npz")
        if os.path.exists(path):
          id2outputs = dict(np.load(path).items())
        else:
          id2outputs = {}
        print(">>> old id2outputs: ", len(id2outputs.keys()))
        id2outputs.update(SpeechModel.id2outputs)
        with open(path, 'wb') as f:
          np.savez(f, **SpeechModel.id2outputs)
      return None

    def save_items(decode_args):
      from usr.na_speech_model import NASpeechModel
      if decode_args.decode_hparams.get('save_items') != "":
        save_items = decode_args.decode_hparams.save_items.split("-")
        save_items = [item.strip() for item in save_items]
        for item in save_items:
          assert item in ['encdec_attn', 'enc_self_attn', 'dec_self_attn', 'shape', 'decode_mels', 'gt_wavs']

          with open(os.path.join(FLAGS.output_dir, item + ".npz"), 'wb') as f:
            exec('np.savez(f, **NASpeechModel.id2' + item + ')')

      return None
    return [save_id2attn, save_id2outputs,save_items]
