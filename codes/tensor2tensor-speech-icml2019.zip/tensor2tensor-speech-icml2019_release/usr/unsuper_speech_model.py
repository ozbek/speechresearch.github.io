# coding=utf-8
# Copyright 2018 The Tensor2Tensor Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Transformer model from "Attention Is All You Need".

The Transformer model consists of an encoder and a decoder. Both are stacks
of self-attention layers followed by feed-forward layers. This model yields
good results on a number of problems, especially in NLP and machine translation.

See "Attention Is All You Need" (https://arxiv.org/abs/1706.03762) for the full
description of the model and the results obtained with its early version.
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import numpy as np
import tensorflow as tf

from tensor2tensor.utils import registry
# Alias some commonly reused layers, here and elsewhere.
from tensor2tensor.utils.t2t_model import log_info
from usr.speech_model import SpeechModel, transformer_speech, transformer_speech_middle

flags = tf.flags
FLAGS = flags.FLAGS


@registry.register_model
class UnsuperSpeechModel(SpeechModel):
  def __init__(self, *args, **kwargs):
    super().__init__(*args, **kwargs)
    hparams = self._hparams
    self.train_params = {
      'layer_prepostprocess_dropout': float(hparams.layer_prepostprocess_dropout),
      'relu_dropout': float(hparams.relu_dropout),
      'attention_dropout': float(hparams.attention_dropout),
      'is_training': self._is_training_at_beginning,
    }

  def model_fn(self, features, run_type=None, print_vars=True, return_encoder_out=False, encoder_output=None):
    losses = {'extra': 0.0, 'training': 0.0}

    def model_fn_combine_loss(run_type=None):
      training_loss = super(UnsuperSpeechModel, self).model_fn(features, run_type, random_print=True)[1]['training']
      training_loss = training_loss[0] / training_loss[1]
      return training_loss

    data_type = features['data_type'][0]
    if self.hparams.ts_lambda > 0:
      losses['loss_ts'] = tf.cond(
        tf.equal(data_type[0], tf.constant(0)),
        lambda: model_fn_combine_loss('t->s') * self.hparams.ts_lambda,
        lambda: tf.constant(0.))

    if self.hparams.st_lambda > 0:
      losses['loss_st'] = tf.cond(
        tf.logical_or(
          tf.logical_and(tf.equal(data_type[0], tf.constant(0)),
                         tf.equal(data_type[1], tf.constant(0))),
          tf.logical_and(tf.equal(data_type[0], tf.constant(1)),
                         tf.equal(data_type[1], tf.constant(1)))
        ),
        lambda: model_fn_combine_loss('s->t') * self.hparams.st_lambda,
        lambda: tf.constant(0.))

    if self.hparams.tt_lambda > 0 or self.hparams.ss_lambda > 0:
      losses['loss_ae'] = tf.cond(tf.equal(
        data_type[0], tf.constant(2)),
        lambda: model_fn_combine_loss('t->t') * self.hparams.tt_lambda +
                model_fn_combine_loss('s->s') * self.hparams.ss_lambda,
        lambda: tf.constant(0.))

    return tf.zeros((0,)), losses

  def _model_fn_with_eout(self, features, encoder_output=None):
    inputs_shape = tf.shape(features['inputs'])
    if self.encoder_layer_prefix == self.decoder_layer_prefix and self.hparams.dae_type == 'mass':
      l = inputs_shape[1] // 2
      lens = tf.reduce_sum(tf.reshape(tf.to_int32(
        tf.not_equal(tf.reduce_sum(tf.abs(features['inputs']), 2), 0)  # (B,L,1)
      ), [inputs_shape[0], inputs_shape[1]]), -1) // 2
      start = tf.random_uniform([inputs_shape[0]], 0, inputs_shape[1] - l, tf.int32)
      end = start + lens
      mass_mask = tf.to_float(tf.reshape(
        tf.logical_and(tf.logical_not(tf.sequence_mask(start, inputs_shape[1])), tf.sequence_mask(end, inputs_shape[1])),
        [inputs_shape[0], inputs_shape[1], 1, 1]))
      if self.encoder_layer_prefix == 's':
        with tf.variable_scope(f'mass_mask_{self.encoder_layer_prefix}'):
          mask_emb = tf.get_variable(
            'mask_emb', [1, 1, self.hparams.audio_num_mel_bins, 1], tf.float32)
        features['inputs'] = \
          tf.tile(
            mask_emb,
            [inputs_shape[0], inputs_shape[1], 1, 1]
          ) * mass_mask + features['inputs'] * (1 - mass_mask)

    with tf.variable_scope(tf.get_variable_scope(), use_resource=True) as vs:
      self._add_variable_scope("model_fn", vs)
      transformed_features = self.bottom(features)

    if self.encoder_layer_prefix == self.decoder_layer_prefix and self.hparams.dae_type == 'mass':
      if self.encoder_layer_prefix == 't':
        with tf.variable_scope(f'mass_mask_{self.encoder_layer_prefix}'):
          mask_emb = tf.get_variable(
            'mask_emb', [1, 1, 1, self.hparams.hidden_size], tf.float32)
        transformed_features['inputs'] = \
          tf.tile(
            mask_emb,
            [inputs_shape[0], inputs_shape[1], 1, 1]
          ) * mass_mask + transformed_features['inputs'] * (1 - mass_mask)
      transformed_features['targets'] = transformed_features['targets'] * mass_mask
      features['targets'] = features['targets'] * tf.cast(mass_mask, features['targets'].dtype)

    with tf.variable_scope("body", reuse=tf.AUTO_REUSE) as body_vs:
      self._add_variable_scope("body", body_vs)
      log_info("Building model body")
      body_out = self.body(transformed_features, encoder_output)
    body_out, losses = self._normalize_body_output(body_out)
    body_out['logits'] = self.top(body_out['decoder_output'], features)
    if self.encoder_layer_prefix == self.decoder_layer_prefix and self.hparams.dae_type == 'mass':
      if self.encoder_layer_prefix == 's':
        body_out['logits'] = body_out['logits'] * tf.squeeze(tf.cast(mass_mask, body_out['logits'].dtype), axis=-1)
      elif self.encoder_layer_prefix == 't':
        body_out['logits'] = body_out['logits'] * tf.expand_dims(tf.cast(mass_mask, body_out['logits'].dtype), axis=-1)
    training_loss = self.loss(body_out['logits'], features)
    if isinstance(training_loss[0], list):
      training_loss = training_loss[0]
      losses['training'] = training_loss[0] + training_loss[1] + training_loss[2] + training_loss[3], tf.constant(1.0)
      losses['mel_loss'] = training_loss[0]
      losses['postnet_loss'] = training_loss[1]
      losses['linear_loss'] = training_loss[2]
    else:
      losses['training'] = training_loss
    return body_out, losses

  def set_modules_and_get_features(self, run_type, features=None):
    _features = super(UnsuperSpeechModel, self).set_modules_and_get_features(run_type, features)

    if run_type.split('->')[0] == run_type.split('->')[-1]:
      inputs_shape = tf.shape(_features['inputs'])
      if self.hparams.dae_type == 'dae':
        random_uniform_mask = tf.expand_dims(tf.expand_dims(tf.to_float(
          tf.random_uniform([inputs_shape[0], inputs_shape[1]]) < self.hparams.mask_noise_prob
        ), axis=2), axis=3)
        random_uniform_mask = tf.cast(random_uniform_mask, _features['inputs'].dtype)
        _features['inputs'] = _features['inputs'] * (1 - random_uniform_mask)

    if self.hparams.add_reverse and features:
      source_type, target_type = run_type.split("->")
      bs = tf.shape(_features['inputs'])[0]
      one_mat = tf.ones([bs], tf.int64)
      reverse_ = False

      if self._is_training_at_beginning:
        if target_type == 's':
          if self.hparams.reverse_speech:
            _features['stoken'] = tf.concat([one_mat * 0, one_mat * 1], 0)
            reverse_tar = self.reverse_speech
            reverse_ = True
          else:
            _features['stoken'] = tf.concat([one_mat * 0, one_mat * 0], 0)
            reverse_tar = lambda x: x
        else:
          if self.hparams.reverse_text:
            _features['stoken'] = tf.concat([one_mat * 2, one_mat * 3], 0)
            reverse_tar = self.reverse_text
            reverse_ = True
          else:
            _features['stoken'] = tf.concat([one_mat * 2, one_mat * 2], 0)
            reverse_tar = lambda x: x

        if self.hparams.reverse_encoder_inp and reverse_:
          if source_type == 's':
            reverse_inp = self.reverse_speech
          else:
            reverse_inp = self.reverse_text
        else:
          reverse_inp = lambda x: x
        # print(">>> reverse func: ", reverse_inp, reverse_tar)
        _features['inputs'] = tf.concat([_features['inputs'], reverse_inp(_features['inputs'])], 0)
        _features['targets'] = tf.concat([_features['targets'], reverse_tar(_features['targets'])], 0)
        _features['data_type'] = tf.concat([_features['data_type'], _features['data_type']], 0)
        _features['utt_id'] = tf.concat([_features['utt_id'], _features['utt_id']], 0)
      else:
        if not self.hparams.decode_reverse:
          if target_type == 's':
            _features['stoken'] = tf.concat([one_mat * 0], 0)
          else:
            _features['stoken'] = tf.concat([one_mat * 2], 0)
        else:
          if target_type == 's':
            _features['stoken'] = tf.concat([one_mat * 1], 0)
            _features['inputs'] = self.reverse_text(_features['inputs'])
            _features['targets'] = self.reverse_speech(_features['targets'])
          else:
            _features['stoken'] = tf.concat([one_mat * 3], 0)
            _features['inputs'] = self.reverse_speech(_features['inputs'])
            _features['targets'] = self.reverse_text(_features['targets'])

    return _features

  @staticmethod
  def reverse_speech(inputs):
    inputs_shape = tf.shape(inputs)
    inputs = tf.reshape(inputs, [inputs_shape[0], inputs_shape[1], inputs_shape[2] * inputs_shape[3], 1])
    weights = tf.to_float(tf.not_equal(tf.reduce_sum(tf.abs(tf.squeeze(inputs, -1)), -1), 0))  # eos and pad
    valid_token_num = tf.reduce_sum(weights, axis=1)
    inputs_reverse = tf.reverse_sequence(inputs, tf.to_int32(valid_token_num), seq_axis=1, batch_axis=0)
    inputs_reverse = tf.reshape(inputs_reverse, [inputs_shape[0], inputs_shape[1], inputs_shape[2], inputs_shape[3]])
    return inputs_reverse

  @staticmethod
  def reverse_text(inputs):
    inputs_ = tf.squeeze(inputs, [-1, -2])
    weights = tf.to_float(tf.logical_and(tf.not_equal(inputs_, 0), tf.not_equal(inputs_, 1)))  # eos and pad
    valid_token_num = tf.reduce_sum(weights, axis=1)
    inputs_reverse = tf.reverse_sequence(inputs, tf.to_int32(valid_token_num), seq_axis=1, batch_axis=0)
    return inputs_reverse

  def print_loss_in_model_fn(self, losses, features, run_type):
    txt = f"[{run_type}]"
    print_tensor = []
    for k, v in losses.items():
      if isinstance(v, list) or isinstance(v, tuple):
        print_tensor.append(v[0] / v[1])
      else:
        print_tensor.append(v)
      txt += k + ", "
    print_tensor.append(tf.shape(features["inputs"]))
    print_tensor.append(features['data_type'][0])
    txt += 'inputs_shape: '
    return print_tensor, txt

  def decode(self,
             decoder_input,
             encoder_output,
             encoder_decoder_attention_bias,
             decoder_self_attention_bias,
             hparams,
             cache=None,
             decode_loop_step=None,
             nonpadding=None,
             losses=None,
             return_attn=False,
             layer_names=None):
    self.attention_weights = {}
    return super(UnsuperSpeechModel, self).decode(decoder_input,
                                                  encoder_output,
                                                  encoder_decoder_attention_bias,
                                                  decoder_self_attention_bias,
                                                  hparams,
                                                  cache,
                                                  decode_loop_step,
                                                  nonpadding,
                                                  losses,
                                                  return_attn,
                                                  layer_names)

@registry.register_hparams
def transformer_unsuper_speech():
  """HParams for training TTS model."""
  hparams = transformer_speech_middle()
  hparams.add_hparam('dae_type', 'dae')
  hparams.add_hparam("mask_noise_prob", 0.3)
  hparams.add_hparam("bt_loss", True)
  hparams.add_hparam("bert_noise_prob", 0.15)
  hparams.add_hparam("bt_steps", 20000)
  hparams.add_hparam("ae_stop_steps", 50000)
  hparams.add_hparam("train_mode", 'align+ae+bt')
  hparams.add_hparam("para_data", 200)
  hparams.add_hparam("n_mono_data", 10000)
  hparams.add_hparam("mono_data", 'all')
  hparams.add_hparam("add_reverse", True)
  hparams.add_hparam("reverse_text", True)
  hparams.add_hparam("reverse_speech", True)
  hparams.add_hparam("reverse_encoder_inp", True)
  hparams.add_hparam("st_lambda", 1.)
  hparams.add_hparam("ts_lambda", 1.)
  hparams.add_hparam("tt_lambda", 1.)
  hparams.add_hparam("ss_lambda", 1.)

  hparams.add_hparam("decode_reverse", False)
  hparams.add_hparam("test_dataset", 'test')
  hparams.add_hparam("decode_for_test", True)
  hparams.add_hparam("bt_data_from", '')

  hparams.pos_scale = False
  hparams.num_decoder_layers = 4
  hparams.num_encoder_layers = 6
  hparams.batch_size = 600000
  hparams.no_sa = False
  hparams.glu = False
  hparams.enc_prenet = True
  hparams.conv_first_kernel = 1
  return hparams


@registry.register_hparams
def transformer_unsuper_speech_student():
  hparams = transformer_unsuper_speech()
  hparams.no_sa = True
  hparams.glu = True
  hparams.enc_prenet = False
  hparams.conv_first_kernel = 9
  hparams.num_encoder_layers = 4
  hparams.predict_linear = True
  hparams.batch_size = 8000000
  hparams.para_data = -1
  return hparams
