import os
import random
import re
from glob import glob

import numpy as np
import tensorflow as tf

from tensor2tensor.data_generators import generator_utils
from tensor2tensor.data_generators.problem import skip_random_fraction, DatasetSplit
from tensor2tensor.utils.decoding import _save_until_eos
from usr.speech_problem import SpeechProblem

flags = tf.flags
FLAGS = flags.FLAGS


class UnsuperSpeechProblem(SpeechProblem):
  bt_store = {
    't->s': {},
    's->t': {},
  }

  @property
  def num_shards(self):
    return 100

  def example_reading_spec(self):
    data_fields = {
      "inputs": tf.VarLenFeature(tf.int64),
      "mel_data": tf.VarLenFeature(tf.float32),
      "utt_id": tf.VarLenFeature(tf.int64),
    }

    data_items_to_decoders = None
    return data_fields, data_items_to_decoders

  def input_fn(self,
               mode,
               hparams,
               data_dir=None,
               params=None,
               config=None,
               force_repeat=False,
               prevent_repeat=False,
               dataset_kwargs=None,
               batch_shuffle_size=32):
    is_training = mode == tf.estimator.ModeKeys.TRAIN

    if is_training:
      step_stages = None
      hparams.optimizer_multistep_accumulate_steps = 1
      if hparams.train_mode == 'align' or hparams.bt_data_from != '':
        hparams.tt_lambda = 0.
        hparams.ss_lambda = 0.
        if hparams.run_type == 't->s':
          hparams.st_lambda = 0.
        else:
          hparams.ts_lambda = 0.

        if hparams.bt_data_from != "":
          if hparams.run_type == 't->s':
            all_ds = [4]
          else:
            all_ds = [5]
        else:
          all_ds = [0]

        step_stages = [
          {'start': 0, 'ds_idx': [0]}
        ]

      elif hparams.train_mode == 'align+ae':
        all_ds = [0, 1, 2]
        step_stages = [
          {'start': 0, 'ds_idx': [0, 1, 2]}
        ]

      elif hparams.train_mode == 'align+bt':
        hparams.bt_steps = 1000
        all_ds = [0, 1, 2, 4, 5]
        step_stages = [
          {'start': 0, 'ds_idx': [0, 1, 2, 3, 4]}
        ]

      elif hparams.train_mode == 'self_learning':
        hparams.bt_steps = 1000
        all_ds = [1, 2]
        step_stages = [
          {'start': 0, 'ds_idx': [0, 1]}
        ]

      elif hparams.train_mode in ['align+ae+bt', 'align+ae+bt+pretrain']:
        all_ds = [0, 2, 4, 5]
        step_stages = [
          {'start': 0, 'ds_idx': [0, 1]},
          {'start': hparams.bt_steps, 'ds_idx': [0, 1, 1, 2, 3, 2, 3, 2, 3]},
          {'start': hparams.ae_stop_steps, 'ds_idx': [0, 2, 3, 2, 3, 2, 3, 2, 3, 2, 3]},
        ]


      datasets = [None for _ in all_ds]
      for idx, dataset_type in enumerate(all_ds):
        self.dataset_type = dataset_type
        datasets[idx] = super().input_fn(mode,
                                         hparams,
                                         data_dir,
                                         params,
                                         config,
                                         force_repeat,
                                         prevent_repeat,
                                         dataset_kwargs,
                                         batch_shuffle_size)
      this_run_steps = {'steps': 0}

      def gen_idx():
        stage = 0
        while True:
          for i in step_stages[stage]['ds_idx']:
            this_run_steps['steps'] = this_run_steps['steps'] + 1
            yield i
          if stage < len(step_stages) - 1 and \
              self.runtime_global['steps'] > step_stages[stage + 1]['start']:
            stage += 1

      return tf.contrib.data.choose_from_datasets(datasets, tf.data.Dataset.from_generator(gen_idx, tf.int64))
    else:
      hparams.para_data = -1
      self.dataset_type = 0
      return super().input_fn(mode,
                              hparams,
                              data_dir,
                              params,
                              config,
                              force_repeat,
                              prevent_repeat,
                              dataset_kwargs,
                              batch_shuffle_size)


  def dataset(self,
              mode,
              data_dir=None,
              num_threads=None,
              output_buffer_size=None,
              shuffle_files=None,
              hparams=None,
              preprocess=True,
              dataset_split=None,
              shard=None,
              partition_id=0,
              num_partitions=1,
              shuffle_buffer_size=1024,
              max_records=-1,
              only_last=False):
    dataset_type = {
      'batch_prediction_key': tf.int64,
      'inputs': tf.int64,
      'targets': tf.float32,
      'utt_id': tf.int64,
      'data_type': tf.int64,
    }

    audio_dim = self.model_hparams.audio_num_mel_bins + (
      self.model_hparams.num_freq if self.model_hparams.predict_linear else 0)

    dataset_shape = {
      'batch_prediction_key': tf.TensorShape([1, ]),
      'inputs': tf.TensorShape([None, ]),
      'targets': tf.TensorShape([None, audio_dim]),
      'utt_id': tf.TensorShape([1, ]),
      'data_type': tf.TensorShape([2, ]),
    }

    def get_raw_dataset(data_type=0, max_records=-1):
      shuffle_files_ = shuffle_files
      if max_records != -1:
        shuffle_files_ = False
      ds = super(UnsuperSpeechProblem, self).dataset(mode, data_dir,
                                                     num_threads,
                                                     output_buffer_size,
                                                     shuffle_files_,
                                                     hparams,
                                                     preprocess,
                                                     dataset_split,
                                                     shard,
                                                     partition_id,
                                                     num_partitions,
                                                     128,
                                                     max_records,
                                                     only_last)

      def add_dataset_idx(x):
        x['data_type'] = tf.constant([data_type, 0], tf.int64)
        return x

      dataset = ds.map(add_dataset_idx)


      def get_mel_by_speech(s):
        def _get_mel(example):
          if f'targets_{s}' in example:
            example['targets'] = example.pop(f'targets_{s}')
          return example

        return _get_mel

      def del_augment_keys(example):
        if 'targets_11' in example:
          del example['targets_11']
        if 'targets_09' in example:
          del example['targets_09']
        return example

      if (data_type == 0) and 0 < hparams.para_data < 200:
        ds1 = dataset.map(get_mel_by_speech('09')).map(del_augment_keys)
        ds2 = dataset.map(get_mel_by_speech('11')).map(del_augment_keys)
        ds3 = dataset.map(del_augment_keys)
        ds3 = ds3.concatenate(ds1)
        ds3 = ds3.concatenate(ds2)
        dataset = ds3
      else:
        dataset = dataset.map(del_augment_keys)

      if mode == tf.estimator.ModeKeys.TRAIN:
        dataset = dataset.repeat()
        data_files = tf.contrib.slim.parallel_reader.get_data_files(
          self.filepattern(data_dir, mode))
        dataset = skip_random_fraction(dataset, data_files[0])

      return dataset

    ## dataset_idx
    # 0 - para_ts+st
    # 2 - AE_tt+ss
    # 4 - bt_ts
    # 5 - bt_st

    ## data_type:
    # 0,0 - para_data, t->s + s->t
    # 2,0 - t->t+s->s
    # 3,0 - no_loss
    # 0,1 - bt_data, t->s
    # 1,1 - bt_data, s->t

    if self.dataset_type == 0:
      dataset = get_raw_dataset(0, hparams.para_data)
    if self.dataset_type == 2:
      dataset = get_raw_dataset(2)

    def _gen_bt_data(bt_type):
      def gen():
        old_bt_outputs_path = ''
        old_rev_bt_outputs_path = ''
        bt_outputs = []
        bt_rev_outputs = []
        while True:
          if bt_type == 't->s':
            fn_runtype = 's2t'
          else:
            fn_runtype = 't2s'
          if hparams.bt_data_from == "":
            bt_data_dir = FLAGS.output_dir
          else:
            bt_data_dir = "checkpoints/" + hparams.bt_data_from

          bt_outputs_paths = get_all_bt_outputs(fn_runtype, bt_data_dir)
          if len(bt_outputs_paths) > 0:
            bt_outputs_path = bt_outputs_paths[-1]
            if old_bt_outputs_path != bt_outputs_path:
              bt_outputs = list(np.load(bt_outputs_path))
              tf.logging.info(f"Load {bt_outputs_path} data: {len(bt_outputs)}")
            else:
              tf.logging.info(f"{old_bt_outputs_path} data has not been updated..")
            old_bt_outputs_path = bt_outputs_path

          bt_rev_outputs_paths = get_all_bt_outputs(fn_runtype + '_rev', bt_data_dir)
          if len(bt_rev_outputs_paths) > 0:
            bt_outputs_path = bt_rev_outputs_paths[-1]
            if old_rev_bt_outputs_path != bt_outputs_path:
              bt_rev_outputs = list(np.load(bt_outputs_path))
              tf.logging.info(f"Load {bt_outputs_path} data: {len(bt_rev_outputs)}")
            else:
              tf.logging.info(f"{old_bt_outputs_path}_rev data has not been updated..")
            old_rev_bt_outputs_path = bt_outputs_path

          bt_all_outputs = bt_outputs + bt_rev_outputs
          if len(bt_all_outputs) > 0:
            random.shuffle(bt_all_outputs)
            for bt_output in bt_all_outputs:
              mels = bt_output['inputs']
              txt = bt_output['outputs']
              if fn_runtype == 't2s':
                mels, txt = txt, mels
              else:
                if hparams.predict_linear:
                  if 'linear_data' not in bt_output:
                    continue
                  bt_output['linear_data'] = bt_output['linear_data'].reshape(mels.shape[0], -1)
                  mels = mels.reshape(mels.shape[0], -1)
                  mels = np.concatenate([mels, bt_output['linear_data']], -1)

              yield {
                'batch_prediction_key': np.zeros((1,)),
                'inputs': txt.reshape(-1),
                'targets': mels.reshape(-1, audio_dim),
                'utt_id': [-1],
                'data_type': [0, 1] if bt_type == 't->s' else [1, 1],
              }
          else:
            ret = {
              'batch_prediction_key': np.zeros((1,)),
              'inputs': np.random.random_integers(0, 256, size=(300,)),
              'targets': np.random.random((4000, audio_dim)),
              'utt_id': [-1],
              'data_type': [3, 1],
            }
            yield ret

      return gen

    if self.dataset_type == 4:
      def process_bt_mel(example):
        example['targets'] = tf.reshape(example['targets'], [-1, audio_dim, 1])
        return example

      dataset = tf.data.Dataset.from_generator(_gen_bt_data('t->s'), dataset_type, dataset_shape)
      dataset = dataset.map(process_bt_mel)

    if self.dataset_type == 5:
      def process_bt_mel(example):
        example['targets'] = SpeechProblem.process_mel(hparams, example['targets'])
        return example

      dataset = tf.data.Dataset.from_generator(_gen_bt_data('s->t'), dataset_type, dataset_shape)
      dataset = dataset.map(process_bt_mel)

    return dataset

  def filepattern(self, data_dir, mode, shard=None):
    if shard is None or isinstance(shard, int):
      path = os.path.join(data_dir, self.dataset_filename())
      shard_str = "-%05d" % shard if shard is not None else ""
      if mode == DatasetSplit.TRAIN:
        suffix = "train"
      else:
        suffix = "test"
      return "%s-%s%s*" % (path, suffix, shard_str)
    else:
      path = os.path.join(data_dir, self.dataset_filename())
      shard_str = shard
      if mode == DatasetSplit.TRAIN:
        suffix = "train"
      else:
        suffix = "test"
      return "%s-%s-%s" % (path, suffix, shard_str)

  @property
  def decode_hooks(self):
    def save_results(decode_args):
      predictions = decode_args.predictions
      hparams = decode_args.hparams
      if decode_args.decode_hparams.save_results:
        ckpt_steps = hparams.ckpt_path.split("-")[-1]
        flags = tf.flags
        FLAGS = flags.FLAGS
        out_dir = os.path.expanduser(FLAGS.output_dir)
        if hparams.run_type == 't->s':
          run_type = 't2s'
        else:
          run_type = 's2t'

        if hparams.decode_reverse:
          for idx, p in enumerate(predictions):
            predictions[idx]['outputs'] = p['outputs'][::-1]
            predictions[idx]['targets'] = p['targets'][::-1]
            predictions[idx]['inputs'] = p['inputs'][::-1]
          run_type += "_rev"

        if hparams.run_type == 's->t':
          a = 0
          b = 0
          inputs_vocab = self.feature_encoders(None)['inputs']
          for p in predictions[:500]:
            outputs = p['outputs']
            targets = p['targets']
            decoded_outputs = inputs_vocab.decode(_save_until_eos(outputs))
            decoded_targets = inputs_vocab.decode(_save_until_eos(targets))
            from jiwer import wer
            clean_targets = decoded_targets.replace(" |", "").split(" ")
            clean_outputs = decoded_outputs.replace(" |", "").split(" ")
            l = len(clean_targets)

            def compute_er(x, y):
              return wer(" ".join(x), " ".join(y))

            per = compute_er(clean_targets, clean_outputs)
            a += per * l
            b += l

          tf.logging.info(f"outputs: {decoded_outputs}")
          tf.logging.info(f"targets: {decoded_targets}")
          tf.logging.info('PER: {}'.format(a / b))

        file_basename = run_type + "-" + ckpt_steps + '.npy'
        file_basename_incomplete = 'incomplete-' + file_basename
        out_path_incomplete = os.path.join(out_dir, file_basename_incomplete)
        out_path = os.path.join(out_dir, file_basename)
        np.save(out_path_incomplete, predictions)
        tf.logging.info("Saved " + out_path)
        os.system('mv {} {}'.format(out_path_incomplete, out_path))
        all_npys = get_all_bt_outputs(run_type, out_dir)
        print("all npys:", all_npys)
        print("Remove output files: ", all_npys[:-3])
        for f in all_npys[:-3]:
          os.remove(f)

    return [save_results]


def get_all_bt_outputs(run_type, out_dir):
  return sorted(glob(os.path.join(out_dir, run_type + '-*.npy')), key=lambda x: int(re.findall(r'\d+', x)[-1]))
