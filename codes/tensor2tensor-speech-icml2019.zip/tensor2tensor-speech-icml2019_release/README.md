# Unsupervised ASR and TTS

Tensorflow Implementation of "Almost Unsupervised Text to Speech and Automatic Speech Recognition".

This repo is based on tensor2tensor v1.10.0.

Synthesized speech samples can be found in [our demo website](https://speechresearch.github.io/unsuper/)


## Quick Start
1. Prepare LJSpeech dataset
```bash
wget https://data.keithito.com/data/speech/LJSpeech-1.1.tar.bz2
bzip2 -d LJSpeech-1.1.tar.bz2
tar xvf LJSpeech-1.1.tar
mkdir data/ljspeech
mv LJSpeech-1.1/wavs data/ljspeech/LJSpeech-1.1
```

2. Install requirements
```bash
pip install -r requirements.txt
```

3. Prepare tensor2tensor LJSpeech binary data
```bash
problem=ljspeech_unsuper_phone_problem bash runs/data-gen-ljspeech.sh
```

### Train unsupervised model 
```bash
# Suppose you have 4 GPUs, run the main job with 3 GPUs in one terminal
CUDA_VISIBLE_DEVICES=0,1,2 exp_name=train_unsuper bash runs/train-unsuper.sh
# Run the dual transformation job with 1 GPU in another terminal
CUDA_VISIBLE_DEVICES=3 exp_name=train_unsuper python  runs/run_unsuper_infer.py
```

### Generate text on test dataset
```bash
exp_name=train_unsuper hparams="run_type=s->t" bash runs/test-unsuper.sh
```

### Generate speech on test dataset
```bash
exp_name=train_unsuper hparams="run_type=t->s" bash runs/test-unsuper.sh
```

### Distill the new TTS Model

#### Generate back translation outputs with linear
```bash
problem=ljspeech_phone_linear_problem bash runs/data-gen-ljspeech.sh
exp_name=train_unsuper problem=ljspeech_unsuper_phone_linear_problem save_results=True eval_use_test_set=False batch_size=64000000 hparams="run_type=s->t" bash runs/test-unsuper.sh
 ```

#### Train the student model
```bash
bt_data_from=train_unsuper exp_name=train_unsuper_student_tts is_student=True run_type="t->s" bash runs/train-unsuper.sh
```

#### Test the student model
```bash
exp_name=train_unsuper_student_tts hparams="run_type=t->s" is_student=True  bash runs/test-unsuper.sh 
```

### Distill the new ASR Model

#### Generate back translation outputs with linear
```bash
problem=ljspeech_phone_linear_problem bash runs/data-gen-ljspeech.sh
exp_name=train_unsuper problem=ljspeech_unsuper_phone_linear_problem save_results=True eval_use_test_set=False batch_size=64000000 hparams="run_type=t->s" bash runs/test-unsuper.sh
 ```

#### Train the student model
```bash
bt_data_from=train_unsuper exp_name=train_unsuper_student_asr is_student=True run_type="s->t" bash runs/train-unsuper.sh
```

#### Test the student model
```bash
exp_name=train_unsuper_student_asr hparams="run_type=s->t" is_student=True bash runs/test-unsuper.sh
```
