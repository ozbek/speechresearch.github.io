export PYTHONPATH=./:${PYTHONPATH}
binFile=./tensor2tensor/bin

problem=${problem:-ljspeech_phone_problem}
data_dir=${data_dir:-.}
model=${model:-speech_model}
hparams_set=${hparams_set:-transformer_speech_middle}
exp_name=${exp_name:-test}
hparams=${hparams:-""}

#if [[ $save_attention_weights == "True" ]]; then
# gta=True
#fi

gta=${gta:-"False"}
save_attention_weights=${save_attention_weights:-"False"}
eval_use_test_set=${eval_use_test_set:-"True"}
batch_size=${batch_size:-6000000}
#batch_size=4000000

gpu=${gpu:-1}
if [[ $CUDA_VISIBLE_DEVICES != "" ]]; then
  t=(${CUDA_VISIBLE_DEVICES//,/ })
  gpu=${#t[@]}
fi
echo "Using #gpu=$gpu...batch_size=$batch_size"

decode_hparams=${decode_hparams:-"save_attention_weights=$save_attention_weights,gta=$gta,beam_size=1,alpha=1,batch_size=$batch_size"}

data=${data:-ljspeech}
DATA_DIR=$data_dir/data/${data}
TRAIN_DIR=$data_dir/checkpoints/${exp_name}
mkdir -p $TRAIN_DIR

python ${binFile}/t2t-decoder \
  --t2t_usr_dir=./usr \
  --data_dir=${DATA_DIR} \
  --problem=${problem} \
  --hparams=${hparams} \
  --model=$model \
  --hparams_set=${hparams_set} \
  --output_dir=${TRAIN_DIR} \
  --decode_hparams=${decode_hparams} \
  --decode_to_file="./checkpoints/${exp_name}" \
  --eval_use_test_set=$eval_use_test_set \
  --worker_gpu=$gpu 2>&1 | tee -a $TRAIN_DIR/log.txt
