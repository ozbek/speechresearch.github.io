export PYTHONPATH=./:${PYTHONPATH}
binFile=./tensor2tensor/bin

is_student=${is_student:-"False"}
problem=${problem:-ljspeech_unsuper_phone_problem}
data_dir=${data_dir:-.}
model=${model:-unsuper_speech_model}
hparams_set=${hparams_set:-transformer_unsuper_speech}
exp_name=${exp_name:-test}
hparams=${hparams:-""}
save_results=${save_results:-"False"}
eval_use_test_set=${eval_use_test_set:-"True"}
batch_size=${batch_size:-6400000}

gpu=${gpu:-4}
if [[ $CUDA_VISIBLE_DEVICES != "" ]]; then
  t=(${CUDA_VISIBLE_DEVICES//,/ })
  gpu=${#t[@]}
fi

if [[ ${is_student} == "True" ]]; then
  hparams_set=transformer_unsuper_speech_student
  problem=ljspeech_unsuper_phone_linear_problem
  hparams="add_reverse=False"
  batch_size=64000000
fi

decode_hparams=${decode_hparams:-"beam_size=1,alpha=1,batch_size=$batch_size,save_results=$save_results"}
echo "Using #gpu=$gpu...batch_size=$batch_size...decode_hparams=$decode_hparams"
gpu=${gpu:-1}
data=${data:-ljspeech}
DATA_DIR=$data_dir/data/${data}
TRAIN_DIR=$data_dir/checkpoints/${exp_name}
mkdir -p $TRAIN_DIR

cmd="python ${binFile}/t2t-decoder \
  --t2t_usr_dir=./usr \
  --data_dir=${DATA_DIR} \
  --problem=${problem} \
  --hparams=${hparams} \
  --model=$model \
  --hparams_set=${hparams_set} \
  --output_dir=${TRAIN_DIR} \
  --decode_hparams=${decode_hparams} \
  --eval_use_test_set=${eval_use_test_set} \
  --decode_to_file="./checkpoints/${exp_name}" \
  --worker_gpu=1"

`echo $cmd` 2>&1 | tee -a $TRAIN_DIR/test_log.txt
