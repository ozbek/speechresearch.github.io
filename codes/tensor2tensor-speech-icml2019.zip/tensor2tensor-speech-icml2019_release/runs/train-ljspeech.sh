#CUDA_VISIBLE_DEVICES=0,1 problem=ljspeech_unsuper_phone_align_problem hparams_set=transformer_speech  exp_name=super0106_phone_tsonly5 hparams="bt_prob=0.01,unsupervised=False,bt_loss=False" bash runs/train-ljspeech-unsuper.sh

# exp_name=test_tts_big hparams_set=transformer_speech_big hparams="batch_size=6000" bash runs/train-ljspeech.sh
# data_dir=~/code/tensor2tensor-speech exp_name=test_tts_big hparams_set=transformer_speech_big bash runs/train-ljspeech.sh

export PYTHONPATH=./:${PYTHONPATH}
binFile=./tensor2tensor/bin

problem=${problem:-ljspeech_phone_problem}
data_dir=${data_dir:-.}
model=${model:-speech_model}
hparams_set=${hparams_set:-transformer_speech_middle}
exp_name=${exp_name:-ljspeech_test1}
hparams=${hparams:-}
gpu=${gpu:-4}
keep_checkpoint_max=${keep_checkpoint_max:-3}
save_checkpoints_steps=${save_checkpoints_steps:-2000}

if [[ $CUDA_VISIBLE_DEVICES != "" ]]; then
  t=(${CUDA_VISIBLE_DEVICES//,/ })
  gpu=${#t[@]}
fi

echo "Using #gpu=$gpu..."

data=${data:-ljspeech}
steps=${steps:-80000}
DATA_DIR=$data_dir/data/${data}
TRAIN_DIR=$data_dir/checkpoints/${exp_name}
mkdir -p $TRAIN_DIR

cmd="python ${binFile}/t2t-trainer \
  --t2t_usr_dir=./usr \
  --data_dir=$DATA_DIR \
  --schedule=train \
  --output_dir=$TRAIN_DIR \
  --problem=${problem} \
  --model=${model} \
  --hparams_set=${hparams_set} \
  --worker_gpu=$gpu \
  --hparams="$hparams" \
  --train_steps=$steps \
  --keep_checkpoint_max=$keep_checkpoint_max \
  --iterations_per_loop=$save_checkpoints_steps"

echo $cmd >> $data_dir/checkpoints/${exp_name}/run.sh
`echo $cmd` 2>&1 | tee -a $TRAIN_DIR/log.txt
