# CUDA_VISIBLE_DEVICES=0 exp_name=0502_unsuper100_3 python runs/unsuper_infer.py

import os
import time
from glob import glob

exp_name = os.getenv('exp_name', '')
hparams = os.getenv('hparams', '')
out_dir = f'./checkpoints/{exp_name}'
run_type = 's->t'


def refresh_bt_outputs(run_type, reverse=False):
  _hparams = hparams.split(',') + [f'run_type={run_type},para_data=-1,train_mode=align,decode_reverse={reverse}']
  _hparams = [h for h in _hparams if h != '']
  _hparams = ','.join(_hparams)
  os.system(
    f'exp_name={exp_name} hparams="{_hparams}" save_results=True eval_use_test_set=False batch_size=10000000 bash runs/test-unsuper.sh')


while True:
  ckpt_path = os.path.join(out_dir, 'checkpoint')
  if os.path.exists(ckpt_path):
    with open(os.path.join(out_dir, 'checkpoint'), 'r') as f:
      lastest_steps = f.readlines()[0].split('-')[-1].strip()[:-1]
      if int(lastest_steps) >= 16000:
        if len(glob(os.path.join(out_dir, f's2t_reverse-{lastest_steps}.npy'))) == 0:
          refresh_bt_outputs('s->t', True)
          print("Finished reverse s->t")
        if len(glob(os.path.join(out_dir, f's2t-{lastest_steps}.npy'))) == 0:
          refresh_bt_outputs('s->t', False)
          print("Finished s->t")
        if len(glob(os.path.join(out_dir, f't2s-{lastest_steps}.npy'))) == 0:
          refresh_bt_outputs('t->s')
          print("Finished t->s")
  time.sleep(5)
