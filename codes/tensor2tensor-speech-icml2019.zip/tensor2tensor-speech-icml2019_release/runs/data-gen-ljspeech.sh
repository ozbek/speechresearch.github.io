export PYTHONPATH=.:${PYTHONPATH}
binFile=./tensor2tensor/bin
problem=${problem:-ljspeech_char_problem}
datadir=${datadir:-"data/ljspeech"}
python ${binFile}/t2t-datagen \
  --t2t_usr_dir=usr \
  --data_dir=$datadir \
  --problem=$problem
