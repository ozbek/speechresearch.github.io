# CUDA_VISIBLE_DEVICES=1,2,3 exp_name=0503_unsuper200_3 batch_size=700000 bash runs/train-unsuper.sh
# CUDA_VISIBLE_DEVICES=0 exp_name=0502_unsuper200_3 python runs/unsuper_infer.py


export PYTHONPATH=./:${PYTHONPATH}
binFile=./tensor2tensor/bin

is_student=${is_student:-"False"}
problem=${problem:-ljspeech_unsuper_phone_problem}
data_dir=${data_dir:-.}
model=${model:-unsuper_speech_model}
hparams_set=${hparams_set:-transformer_unsuper_speech}
exp_name=${exp_name:-unsuper_ljspeech_test1}
train_mode=${train_mode:-"align+ae+bt"}
para_data=${para_data:-"200"}
bt_data_from=${bt_data_from:-""}

add_reverse=${add_reverse:-"True"}
batch_size=${batch_size:-"600000"}
run_type=${run_type:-"s->t"}
dae_type=${dae_type:-"dae"}
bt_steps=${bt_steps:-"20000"}
keep_checkpoint_max=${keep_checkpoint_max:-"3"}
save_checkpoints_steps=${save_checkpoints_steps:-"2000"}

if [[ ${is_student} == "True" ]]; then
  add_reverse=False
  train_mode=align
  para_data=-1
  hparams_set=transformer_unsuper_speech_student
  problem=ljspeech_unsuper_phone_linear_problem
  batch_size=6000000
fi

hparams=${hparams:-"train_mode=$train_mode,para_data=$para_data,batch_size=$batch_size,add_reverse=$add_reverse,bt_data_from=$bt_data_from,run_type=$run_type,dae_type=$dae_type,bt_steps=$bt_steps,gl_on_gpu=False"}

echo $hparams

gpu=${gpu:-4}
if [[ $CUDA_VISIBLE_DEVICES != "" ]]; then
  t=(${CUDA_VISIBLE_DEVICES//,/ })
  gpu=${#t[@]}
fi

echo "Using #gpu=$gpu..."
data=${data:-ljspeech}
DATA_DIR=$data_dir/data/${data}
TRAIN_DIR=$data_dir/checkpoints/${exp_name}
mkdir -p $TRAIN_DIR

python ${binFile}/t2t-trainer \
  --t2t_usr_dir=./usr \
  --data_dir=$DATA_DIR \
  --schedule=train \
  --output_dir=$TRAIN_DIR \
  --problem=${problem} \
  --model=${model} \
  --hparams_set=${hparams_set} \
  --worker_gpu=$gpu \
  --keep_checkpoint_max=$keep_checkpoint_max \
  --iterations_per_loop=$save_checkpoints_steps \
  --hparams="$hparams" 2>&1 | tee $TRAIN_DIR/log.txt
