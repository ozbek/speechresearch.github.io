import pandas as pd
import re


def clean(txt):
  s = ''.join(letter for letter in txt.lower() if 'a' <= letter <= 'z' or letter in [' '])
  s = re.sub('\s+', ' ', s)
  return s


df = pd.read_csv('metadata.csv')

n = 0
with open("ljspeech.txt", 'w',encoding='utf-8') as f:
  for l in df['txt1'][:300]:
    n+= len(clean(l).split(' '))
# print(n)
# f.write(clean(l)+'\n')
# print(" ".join([p.upper() for p in ' '.join([p for p in df['phone'][:300]]).split(' ') if p!='|']))

# word ins del sub
# 4975 159 294 1050
# 100  3.2 5.9 21.1
